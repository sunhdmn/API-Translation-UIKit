//
//  UIScrollView.h
//  UIKit
//UIScrollView是一个能够滚动的视图控件，可以用来展示大量的内容，并且可以通过滚动查看所有的内容,总体来说ScrollView又可以分为两种：第一种是根据手指滑动的力度计算滚动的距离。第二种时以页面为单位一次滑动切换一页，这和IOS桌面左右滑动类似。 有了IOS提供的UIScrollView控件实现这些都不是什么难事。
//  Copyright (c) 2007-2015 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIView.h>
#import <UIKit/UIGeometry.h>
#import <UIKit/UIKitDefines.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, UIScrollViewIndicatorStyle) {//设置滚动条的风格
    UIScrollViewIndicatorStyleDefault,     // black with white border. good against any background默认风格(黑与白的边界。良好的对任何背景)
    UIScrollViewIndicatorStyleBlack,       // black only. smaller. good against a white background黑色风格(只有黑色。小。在白色的背景下)
    UIScrollViewIndicatorStyleWhite        // white only. smaller. good against a black background 白色风格(只有黑色。小。在白色的背景下)
};

typedef NS_ENUM(NSInteger, UIScrollViewKeyboardDismissMode) {//scrollView滚动时隐藏键盘
    UIScrollViewKeyboardDismissModeNone,
    UIScrollViewKeyboardDismissModeOnDrag,      // dismisses the keyboard when a drag begins刚拖动scrollView就隐藏键盘
    UIScrollViewKeyboardDismissModeInteractive, // the keyboard follows the dragging touch off screen, and may be pulled upward again to cancel the dismiss从键盘上面点（scrollView未遮挡部分）向下滑动，键盘会跟着滑动；又往上滑动键盘也会跟着向上滑动;先滚动下UITextView,然后手指贴着屏幕向下划，一直带动键盘退出屏幕，这个时候键盘看起来就像是具备交互性的一样，Interactive由此而来。
} NS_ENUM_AVAILABLE_IOS(7_0);

UIKIT_EXTERN const CGFloat UIScrollViewDecelerationRateNormal NS_AVAILABLE_IOS(3_0);
UIKIT_EXTERN const CGFloat UIScrollViewDecelerationRateFast NS_AVAILABLE_IOS(3_0);
//规定用户提起手指后的滚动减速速率,你的应用程序可以使用UIScrollViewDecelerationRateNormal和UIScrollViewDecelerationRateFast常量作为引用点以获得一个合理的减速速率。
@class UIEvent, UIImageView, UIPanGestureRecognizer, UIPinchGestureRecognizer;
@protocol UIScrollViewDelegate;

NS_CLASS_AVAILABLE_IOS(2_0) @interface UIScrollView : UIView <NSCoding>

@property(nonatomic)         CGPoint                      contentOffset;                  // default CGPointZerocontentOffset是scrollview当前显示区域顶点相对于frame顶点的偏移量，比如上个例子你拉到最下面，contentoffset就是(0 ,480)，也就是y偏移了480
@property(nonatomic)         CGSize                       contentSize;                    // default CGSizeZerocontentSize是scrollview可以滚动的区域，比如frame = (0 ,0 ,320 ,480) contentSize = (320 ,960)，代表你的scrollview可以上下滚动，滚动区域为frame大小的两倍。
@property(nonatomic)         UIEdgeInsets                 contentInset;                   // default UIEdgeInsetsZero. add additional scroll area around content  contentInset是scrollview的contentview的顶点相对于scrollview的位置，例如你的contentInset = (0 ,100)，那么你的contentview就是从scrollview的(0 ,100)开始显示

@property(nullable,nonatomic,weak) id<UIScrollViewDelegate>        delegate;                       // default nil. weak reference
@property(nonatomic,getter=isDirectionalLockEnabled) BOOL directionalLockEnabled;         // default NO. if YES, try to lock vertical or horizontal scrolling while dragging默认行为是允许用户同时进行横向和纵向的滚动。将这个属性设置为YES会导致将用户的滚动行为锁定成只允许横向或纵向进行，具体方向由初始姿态决定。


@property(nonatomic)         BOOL                         bounces;                        // default YES. if YES, bounces past edge of content and back again当用户抵达滚动区域边缘时，这个功能允许用户稍微拖动到边界外一点。当用户松开手指后，这个区域会像个橡皮筋一样，弹回到原位，给用户一个可见的提示，表示他已经到达了文档开始或结束位置。如果不想让用户的滚动范围能够超出可见内容，可以将这个属性设置为NO。
@property(nonatomic)         BOOL                         alwaysBounceVertical;           // default NO. if YES and bounces is YES, even if content is smaller than bounds, allow drag vertically
@property(nonatomic)         BOOL                         alwaysBounceHorizontal;         // default NO. if YES and bounces is YES, even if content is smaller than bounds, allow drag horizontally
//bounces用来控制滚动视图是否反弹，bounces默认是YES，当它为NO的时候，其他两个属性值设置无效，滚动视图无法反弹；只有当bounces是YES的时候，其他两个属性设置才有效，alwaysBounceVertical设置垂直方向的反弹是否有效，alwaysBounceHorizontal设置水平方向的反弹是否有效；UITableView默认情况下alwaysBounceVertical是YES，alwaysBounceHorizontal是NO；UIScrollViewUICollectionView默认情况下alwaysBounceVertical和alwaysBounceHorizontal都是NO；只有当内容视图的尺寸超过了自己的bounds的尺寸的时候，相应方向上反弹属性才会自动设置为YES；实现滚动视图的下拉和上拉刷新的时候，就要相应的打开alwaysBounceVertical属性，才能实现下拉和上拉功能；例如UICollectionView页面只有一条数据的时候，内容视图没用占据到UICollectionView的整个bounds，当前就无法滚动，这个时候就要设置alwaysBounceVertical为YES，才能在垂直方向实现反弹进而实现上下拉刷新功能。

@property(nonatomic,getter=isPagingEnabled) BOOL          pagingEnabled __TVOS_PROHIBITED;// default NO. if YES, stop on multiples of view bounds设置pagingEnabled=YES即可，UIScrollView会被分割成多个独立页面，用户的滚动体验则变成了页面翻转
@property(nonatomic,getter=isScrollEnabled) BOOL          scrollEnabled;                  // default YES. turn off any dragging temporarily	是否能滚动
@property(nonatomic)         BOOL                         showsHorizontalScrollIndicator; // default YES. show indicator while we are tracking. fades out after tracking隐藏垂直滚动条
@property(nonatomic)         BOOL                         showsVerticalScrollIndicator;   // default YES. show indicator while we are tracking. fades out after tracking隐藏水平滚动条
@property(nonatomic)         UIEdgeInsets                 scrollIndicatorInsets;          // default is UIEdgeInsetsZero. adjust indicators inside of insets指定滚动条在scrollerView中的位置
@property(nonatomic)         UIScrollViewIndicatorStyle   indicatorStyle;                 // default is UIScrollViewIndicatorStyleDefault设置滚动条颜色，默认风格(黑与白的边界。良好的对任何背景)
@property(nonatomic)         CGFloat                      decelerationRate NS_AVAILABLE_IOS(3_0);//可能通过decelerationRate的属性来设置，它的值域是（0.0，1.0）,当decelerationRate设置为0.1时，当手指touch up时就会很慢的停下来。

- (void)setContentOffset:(CGPoint)contentOffset animated:(BOOL)animated;  // animate at constant velocity to new offset监控目前滚动的位置,功能是跳转到你指定内容的坐标,在你执行setContentOffset方法过后,再执行其他操作时,指定内容的坐标将被还原,pagingEnabled属性会对它进行重置.
//因为setContentOffset animation 有时候卡顿 所以写此方法
//-(void)setBgContentOffsetAnimation:(CGFloat )OffsetY
//{    [UIView animateWithDuration:.25 animations:^
//    {
//        bgScrollView.contentOffset = CGPointMake(0, OffsetY);
//    }];
//}
//出现这种情况的原因有很多
//1:runloop 中原因 系统为了资源禁用了动画 和其他事件的接收
//2:短时间多次调用此方法 系统取消了动画
//3:跟其他动画冲突


- (void)scrollRectToVisible:(CGRect)rect animated:(BOOL)animated;         // scroll so rect is just visible (nearest edges). nothing if rect completely visible滚动一个特定区域的内容以便它在接收是可见的,此方法滚动查看内容，以便由rect定义的区域仅仅是滚动视图内是可见的。如果该地区已是可见的，该方法什么都不做。

- (void)flashScrollIndicators;             // displays the scroll indicators for a short time. This should be done whenever you bring the scroll view to front.当你把滚动视图移动到前面，你应该调用此方法。

/*
 Scrolling with no scroll bars is a bit complex. on touch down, we don't know if the user will want to scroll or track a subview like a control.
 on touch down, we start a timer and also look at any movement. if the time elapses without sufficient change in position, we start sending events to
 the hit view in the content subview. if the user then drags far enough, we switch back to dragging and cancel any tracking in the subview.
 the methods below are called by the scroll view and give subclasses override points to add in custom behaviour.
 you can remove the delay in delivery of touchesBegan:withEvent: to subviews by setting delaysContentTouches to NO.
 */

@property(nonatomic,readonly,getter=isTracking)     BOOL tracking;        // returns YES if user has touched. may not yet have started dragging 当touch后还没有拖动的时候值是YES，否则NO
@property(nonatomic,readonly,getter=isDragging)     BOOL dragging;        // returns YES if user has started scrolling. this may require some time and or distance to move to initiate dragging是否正在被拖拽
@property(nonatomic,readonly,getter=isDecelerating) BOOL decelerating;    // returns YES if user isn't dragging (touch up) but scroll view is still moving是否正在减速

@property(nonatomic) BOOL delaysContentTouches;       // default is YES. if NO, we immediately call -touchesShouldBegin:withEvent:inContentView:. this has no effect on pressesdelaysContentTouches。默认值为YES；如果设置为NO，则无论手指移动的多么快，始终都会将触摸事件传递给内部控件；设置为NO可能会影响到UIScrollView的滚动功能。
@property(nonatomic) BOOL canCancelContentTouches;    // default is YES. if NO, then once we start tracking, we don't try to drag if the touch moves. this has no effect on presses假如你设置canCancelContentTouches为YES，那么当你在UIScrollView上面放置任何子视图的时候,当你在子视图上移动手指的时候，UIScrollView会给子视图发送touchCancel的消息。而如果该属性设置为NO，ScrollView本身不处理这个消息，全部交给子视图处理。(默认是肯定的。如果没有,那么一旦我们开始跟踪,我们不要试图拖如果触摸动作。这对按没有影响)

// override points for subclasses to control delivery of touch events to subviews of the scroll view
// called before touches are delivered to a subview of the scroll view. if it returns NO the touches will not be delivered to the subview
// this has no effect on presses
// default returns YES(子类覆盖点控制的触摸事件滚动视图的子视图称为触摸之前送到滚动视图的子视图。如果它返回没有触动不会交付给子视图这对按默认返回是的没有影响)
- (BOOL)touchesShouldBegin:(NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event inContentView:(UIView *)view;//父视图是否可以将消息传递给子视图，yes是将事件传递给子视图，则不滚动，no是不传递则继续滚动//自定义默认行为，当手指触摸在显示的内容由子类重写。//UIScrollView的默认行为是调用触摸事件发生的UIResponder的事件处理方法的目标子视图

参数：

touches     //一个涉及的UITouch实例集代表表示事件的开始阶段

event        //代表在触摸触摸对象属于事件的对象。

view          //在内容中发生触摸手势子视图。

Return Value     //返回NO ，如果你不想滚动视图发送的事件消息查看。如果你想以接收这些消息，返回YES （默认） 。


// called before scrolling begins if touches have already been delivered to a subview of the scroll view. if it returns NO the touches will continue to be delivered to the subview and scrolling will not occur
// not called if canCancelContentTouches is NO. default returns YES if view isn't a UIControl
// this has no effect on presses(称为滚动开始前如果触摸已经交付给一个滚动视图的子视图。如果它没有返回任何触动将继续交付给子视图和滚动不会发生不叫如果canCancelContentTouches是否定的。默认返回是的观点不是UIControl这对按没有影响)
- (BOOL)touchesShouldCancelInContentView:(UIView *)view;
//Yes是子视图取消继续接受touch消息（可以滚动），NO是子视图可以继续接受touch事件（不滚动）
//默认的情况下当view不是一个UIControlo类的时候，值是yes,否则是no
//调用情况是这样的一般是在发送tracking messages消息后会调用这个函数，来判断scroll是否滚动，还是接受子视图的touch事件//返回是否取消有关的内容子视图的接触，并开始拖动。 //它开始发送跟踪邮件的内容视图后动视图调用此方法。如果它从这种方法收到NO便停止拖动和转发触摸事件的内容子视图。滚动视图不调用此方法如果canCancelContentTouches 属性值是NO
//
//参数：
//
//view        在内容中被触发的视图对象
//
//Return Value    //YES取消进一步触控消息查看，NO查看继续收到这些消息。如果视图认为是不是一个UIControl对象默认YES，否则返回NO
/*
 the following properties and methods are for zooming. as the user tracks with two fingers, we adjust the offset and the scale of the content. When the gesture ends, you should update the content
 as necessary. Note that the gesture can end and a finger could still be down. While the gesture is in progress, we do not send any tracking calls to the subview.
 the delegate must implement both viewForZoomingInScrollView: and scrollViewDidEndZooming:withView:atScale: in order for zooming to work and the max/min zoom scale must be different
 note that we are not scaling the actual scroll view but the 'content view' returned by the delegate. the delegate must return a subview, not the scroll view itself, from viewForZoomingInScrollview:(以下属性和方法进行缩放。随着用户跟踪和两个手指,我们调整抵消和内容的规模。当动作结束时,你应该更新内容这是很有必要的。注意手势可以结束,手指仍有可能下降。虽然动作正在进行中,我们不发送任何跟踪调用子视图。委托必须实现viewForZoomingInScrollView:和scrollViewDidEndZooming:withView:atScale:为了使缩放缩放工作和规模必须是不同的注意,我们不扩展实际的滚动视图但返回的内容视图的委托。委托必须返回一个视图,而不是滚动视图本身,从viewForZoomingInScrollview:)
 */

@property(nonatomic) CGFloat minimumZoomScale;     // default is 1.0缩小的最小比例
@property(nonatomic) CGFloat maximumZoomScale;     // default is 1.0. must be > minimum zoom scale to enable zooming缩大的最小比例 （默认是1.0倍，必须大于最小缩放比例才能进行缩放）

@property(nonatomic) CGFloat zoomScale NS_AVAILABLE_IOS(3_0);            // default is 1.0设置变化比例
- (void)setZoomScale:(CGFloat)scale animated:(BOOL)animated NS_AVAILABLE_IOS(3_0);
////一个浮点数指定当前的缩放比例//新的值应该在是minimumZoomScale和maximumZoomScale之间

参数：

scale         //缩放内容的新的值。

animated    //YES推动过渡到新的规模， NO 以使立即过渡。


- (void)zoomToRect:(CGRect)rect animated:(BOOL)animated NS_AVAILABLE_IOS(3_0);
//缩小到特定区域的内容，所以它是在接收器中可见。 //这种方法调整的zoomScale进行必要的缩放以便使内容视图成为由矩形定义的区域rect          //矩形定义内容视图区

animated          //YES if the scrolling should be animated, NO if it should be immediate.


@property(nonatomic) BOOL  bouncesZoom;          // default is YES. if set, user can go past min/max zoom while gesturing and the zoom will animate to the min/max value at gesture end／／类似bounds 指的用户的缩放//NO时缩放不可超出最大最小缩放范围(默认是肯定的。如果设置,用户可以经过最小/最大缩放手势和变焦将动画的最大/最小值的姿态结束)

@property(nonatomic,readonly,getter=isZooming)       BOOL zooming;       // returns YES if user in zoom gesture是否正在缩放（如果返回是的用户在缩放手势）
@property(nonatomic,readonly,getter=isZoomBouncing)  BOOL zoomBouncing;  // returns YES if we are in the middle of zooming back to the min/max value判断是否正在进行缩放反弹，当内容放大到最大或者最小的时候,值是YES,否则NO（返回是的如果我们中间的缩放回最大/最小值）

// When the user taps the status bar, the scroll view beneath the touch which is closest to the status bar will be scrolled to top, but only if its `scrollsToTop` property is YES, its delegate does not return NO from `shouldScrollViewScrollToTop`, and it is not already at the top.
// On iPhone, we execute this gesture only if there's one on-screen scroll view with `scrollsToTop` == YES. If more than one is found, none will be scrolled.（当用户水龙头状态栏时,滚动视图下的接触最亲密的状态栏会滚动到顶部,但前提是其“scrollsToTop”属性是肯定的,其委托不返回任何从‘shouldScrollViewScrollToTop’,这不是已经在顶部。在iPhone,我们执行这个动作只有在有一个屏幕滚动视图与scrollsToTop = = YES。如果找到一个以上的,都将被滚动。）
@property(nonatomic) BOOL  scrollsToTop __TVOS_PROHIBITED;          // default is YES.控制控件滚动到顶部

// Use these accessors to configure the scroll view's built-in gesture recognizers.
// Do not change the gestures' delegates or override the getters for these properties.（使用这些访问器来配置滚动视图的内置手势识别器。不改变姿势的代表或覆盖这些属性的getter方法。）
@property(nonatomic, readonly) UIPanGestureRecognizer *panGestureRecognizer NS_AVAILABLE_IOS(5_0);
// `pinchGestureRecognizer` will return nil when zooming is disabled.
//UIGestureRecognizer是一个定义基本手势的抽象类，具体什么手势，在以下子类中包含：
//1、拍击UITapGestureRecognizer (任意次数的拍击)
//2、向里或向外捏UIPinchGestureRecognizer (用于缩放)
//3、摇动或者拖拽UIPanGestureRecognizer (拖动)
//4、擦碰UISwipeGestureRecognizer (以任意方向)
//5、旋转UIRotationGestureRecognizer (手指朝相反方向移动)
//6、长按UILongPressGestureRecognizer (长按)（当没有缩放的时候pinchGestureRecognizer返回的是nil）

@property(nullable, nonatomic, readonly) UIPinchGestureRecognizer *pinchGestureRecognizer NS_AVAILABLE_IOS(5_0);
// `directionalPressGestureRecognizer` is disabled by default, but can be enabled to perform scrolling in response to up / down / left / right arrow button presses directly, instead of scrolling indirectly in response to focus updates.（“directionalPressGestureRecognizer”默认情况下是禁用的,但可以启用执行滚动,以应对上/下/左/右箭头按钮直接按,而不是滚动间接回应关注更新。）
@property(nonatomic, readonly) UIGestureRecognizer *directionalPressGestureRecognizer UIKIT_AVAILABLE_TVOS_ONLY(9_0);//定向压手势

@property(nonatomic) UIScrollViewKeyboardDismissMode keyboardDismissMode NS_AVAILABLE_IOS(7_0); // default is UIScrollViewKeyboardDismissModeNone
//self.FirstTextView.keyboardDismissMode  = UIScrollViewKeyboardDismissModeOnDrag;
//self.SecondTextView.keyboardDismissMode = UIScrollViewKeyboardDismissModeInteractive;
//如果是UIScrollViewKeyboardDismissModeOnDrag，那么只要在UITextView中上下滚动一下（就像是滚动UIScrollView一样，里面的滚动条会动）就行了，这个很难截图，就不演示了。
//如果是UIScrollViewKeyboardDismissModeInteractive，这个用文字表述有点吃力，其实就是先滚动下UITextView,然后手指贴着屏幕向下划，一直带动键盘退出屏幕，这个时候键盘看起来就像是具备交互性的一样，Interactive由此而来。
//优点：方便。
//缺点：一，对UITextField无效。二，如果UITextView中的内容较少，无法超过UITextView的范围，也就是不会出现UIScrollView的滚动效果，那么上面的手势都会失效，这样我们又被迫回到方法一写个手势识别器了。
//连scroll的效果都出不来，更加谈不上dismiss keyboard了，这是其最大的不足，希望Apple会改进。

@end

@protocol UIScrollViewDelegate<NSObject>

@optional

- (void)scrollViewDidScroll:(UIScrollView *)scrollView;     // any offset changes/ 触摸屏幕来滚动画面还是其他的方法使得画面滚动，皆触发该函数  使用方法：CGPoint point=scrollView.contentOffset;// 从中可以读取contentOffset属性以确定其滚动到的位置。// 注意：当ContentSize属性小于Frame时，将不会出发滚动

- (void)scrollViewDidZoom:(UIScrollView *)scrollView NS_AVAILABLE_IOS(3_2); // any zoom scale changes当scrollView缩放时，就会调用这个方法,这个方法在任何方式触发 contentOffset 变化的时候都会被调用（包括用户拖动，减速过程，直接通过代码设置等），可以用于监控 contentOffset 的变化，并根据当前的 contentOffset 对其他 view 做出随动调整。在缩放过程中，回多次调用（任何缩放尺度变化）

// called on start of dragging (may require some time and or distance to move)（呼吁开始拖动(可能需要一段时间或距离移动)）
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView;//即将拖拽的时候调用.用户开始拖动 scroll view 的时候被调用。当开始滚动视图时，执行该方法。一次有效滑动（开始滑动，滑动一小段距离，只要手指不松开，只算一次滑动），只执行一次。
// called on finger up if the user dragged. velocity is in points/millisecond. targetContentOffset may be changed to adjust where the scroll view comes to rest(如果用户拖呼吁手指。速度是在点/毫秒。targetContentOffset可能改变调整滚动视图来休息的地方)
- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset NS_AVAILABLE_IOS(5_0);//// 滑动scrollView，并且手指离开时执行。一次有效滑动，只执行一次。
// 当pagingEnabled属性为YES时，不调用，该方法。该方法从 iOS 5 引入，在 didEndDragging 前被调用，当 willEndDragging 方法中 velocity 为 CGPointZero（结束拖动时两个方向都没有速度）时，didEndDragging 中的 decelerate 为 NO，即没有减速过程，willBeginDecelerating 和 didEndDecelerating 也就不会被调用。反之，当 velocity 不为 CGPointZero 时，scroll view 会以 velocity 为初速度，减速直到 targetContentOffset。值得注意的是，这里的 targetContentOffset 是个指针，没错，你可以改变减速运动的目的地，这在一些效果的实现时十分有用，实例章节中会具体提到它的用法，并和其他实现方式作比较
// called on finger up if the user dragged. decelerate is true if it will continue moving afterwards(如果用户拖呼吁手指。减速是真的以后是否会继续)
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate;//// 滑动视图，当手指离开屏幕那一霎那，调用该方法。一次有效滑动，只执行一次。
// decelerate,指代，当我们手指离开那一瞬后，视图是否还将继续向前滚动（一段距离），经过测试，decelerate=YES。在用户结束拖动后被调用，decelerate 为 YES 时，结束拖动后会有减速过程。注，在 didEndDragging 之后，如果有减速过程，scroll view 的 dragging 并不会立即置为 NO，而是要等到减速结束之后，所以这个 dragging 属性的实际语义更接近 scrolling。
//使用方法：if (decelerate) {NSLog(@"decelerate");}else{NSLog(@"no decelerate");}

- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView;   // called on finger up as we are moving减速动画开始前被调用。
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView;      // called when scroll view grinds to a halt滚动视图减速完成，滚动将停止时，调用该方法。一次有效滑动，只执行一次。使用方法：[_scrollView setContentOffset:CGPointMake(0, 500) animated:YES];
//减速动画结束时被调用，这里有一种特殊情况：当一次减速动画尚未结束的时候再次 drag scroll view，didEndDecelerating 不会被调用，并且这时 scroll view 的 dragging 和 decelerating 属性都是 YES。新的 dragging 如果有加速度，那么 willBeginDecelerating 会再一次被调用，然后才是 didEndDecelerating；如果没有加速度，虽然 willBeginDecelerating 不会被调用，但前一次留下的 didEndDecelerating 会被调用，所以连续快速滚动一个 scroll view 时，delegate 方法被调用的顺序（不含 didScroll）可能是这样的：scrollViewWillBeginDragging:
//scrollViewWillEndDragging: withVelocity: targetContentOffset:
//scrollViewDidEndDragging: willDecelerate:
//scrollViewWillBeginDecelerating:
//scrollViewWillBeginDragging:
//scrollViewWillEndDragging: withVelocity: targetContentOffset:
//scrollViewDidEndDragging: willDecelerate:
//scrollViewWillBeginDecelerating:
//...
//scrollViewWillBeginDragging:
//scrollViewWillEndDragging: withVelocity: targetContentOffset:
//scrollViewDidEndDragging: willDecelerate:
//scrollViewWillBeginDecelerating:
//scrollViewDidEndDecelerating:

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView; // called when setContentOffset/scrollRectVisible:animated: finishes. not called if not animating// 当滚动视图动画完成后，调用该方法，如果没有动画，那么该方法将不被调用
// 有效的动画方法为：
//    - (void)setContentOffset:(CGPoint)contentOffset animated:(BOOL)animated 方法
//    - (void)scrollRectToVisible:(CGRect)rect animated:(BOOL)animated 方法
//（时调用setContentOffset / scrollRectVisible:动画:完成。不叫如果不是）

- (nullable UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView;     // return a view that will be scaled. if delegate returns nil, nothing happens// 返回将要缩放的UIView对象。要执行多次（返回一个视图,将缩放。如果委托返回nil,什么也不会发生）
- (void)scrollViewWillBeginZooming:(UIScrollView *)scrollView withView:(nullable UIView *)view NS_AVAILABLE_IOS(3_2); // called before the scroll view begins zooming its content// 当将要开始缩放时，执行该方法。一次有效缩放，就只执行一次。（滚动视图开始前被称为缩放其内容）
- (void)scrollViewDidEndZooming:(UIScrollView *)scrollView withView:(nullable UIView *)view atScale:(CGFloat)scale; // scale between minimum and maximum. called after any 'bounce' animations// 当缩放结束后，并且缩放大小回到minimumZoomScale与maximumZoomScale之间后（我们也许会超出缩放范围），调用该方法。（最小值和最大值之间的规模。之后调用任何“反弹”动画）

- (BOOL)scrollViewShouldScrollToTop:(UIScrollView *)scrollView;   // return a yes if you want to scroll to the top. if not defined, assumes YES// 指示当用户点击状态栏后，滚动视图是否能够滚动到顶部。需要设置滚动视图的属性：_scrollView.scrollsToTop=YES;（返回一个是的如果你想滚动到顶部。如果没有定义,认为是的）
- (void)scrollViewDidScrollToTop:(UIScrollView *)scrollView;      // called when scrolling animation finished. may be called immediately if already at top（// 当滚动视图滚动到最顶端后，执行该方法）（/ /当滚动动画完成。可能被称为立即如果已经在上面吗）

@end

NS_ASSUME_NONNULL_END
