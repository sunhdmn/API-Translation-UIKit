//
//  UIView.h
//  UIKit
//
//  Copyright (c) 2005-2015 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIResponder.h>
#import <UIKit/UIInterface.h>
#import <UIKit/UIKitDefines.h>
#import <UIKit/UIAppearance.h>
#import <UIKit/UIDynamicBehavior.h>
#import <UIKit/NSLayoutConstraint.h>
#import <UIKit/UITraitCollection.h>
#import <UIKit/UIFocus.h>

NS_ASSUME_NONNULL_BEGIN
//UIView动画枚举
typedef NS_ENUM(NSInteger, UIViewAnimationCurve) {
    //开始和结束缓慢
    UIViewAnimationCurveEaseInOut,         // slow at beginning and end
    //开始缓慢
    UIViewAnimationCurveEaseIn,            // slow at beginning
    //结束缓慢
    UIViewAnimationCurveEaseOut,           // slow at end
    //均速
    UIViewAnimationCurveLinear
    
    /** 使用场景*/
// 举例: [UIView setAnimationCurve:];
};

//UIView内容模式枚举
typedef NS_ENUM(NSInteger, UIViewContentMode) {
    //等比例填充
    UIViewContentModeScaleToFill,
    //等比例缩放图片自适应(不会变形)
    UIViewContentModeScaleAspectFit,      // contents scaled to fit with fixed aspect. remainder is transparent
    //等比例缩放图片填充(不会变形)
    UIViewContentModeScaleAspectFill,     // contents scaled to fill with fixed aspect. some portion of content may be clipped.
    //重绘 Redraw ---> 核心绘画(drawRact)
    UIViewContentModeRedraw,              // redraw on bounds change (calls -setNeedsDisplay)
    //图片显示在中心位置
    UIViewContentModeCenter,              // contents remain same size. positioned adjusted.
    //图片显示在顶部位置
    UIViewContentModeTop,
    //图片显示在底部位置
    UIViewContentModeBottom,
    //图片显示在左边位置
    UIViewContentModeLeft,
    //图片显示在右边位置
    UIViewContentModeRight,
    //图片显示在顶部左边位置
    UIViewContentModeTopLeft,
    //图片显示在顶部右边位置
    UIViewContentModeTopRight,
    //图片显示在底部左边位置
    UIViewContentModeBottomLeft,
    //图片显示在底部右边位置
    UIViewContentModeBottomRight,
    
    /** 使用场景*/
// 举例: UIImageView *image = [[UIImageView alloc]init];
//    image.contentMode = 枚举名
};

//UIView动画形变
typedef NS_ENUM(NSInteger, UIViewAnimationTransition) {
    //动画形变无效果
    UIViewAnimationTransitionNone,
    //动画形变左边翻转
    UIViewAnimationTransitionFlipFromLeft,
    //动画形变右边翻转
    UIViewAnimationTransitionFlipFromRight,
    //动画形变向上卷起
    UIViewAnimationTransitionCurlUp,
    //动画形变往下卷动
    UIViewAnimationTransitionCurlDown,
    
    /** 使用场景*/
    //举例:[UIView setAnimationTransition: 枚举名 forView: 自定义的View cache: BOOL值 ];
};

//UIView自动布局枚举
typedef NS_OPTIONS(NSUInteger, UIViewAutoresizing) {
    //自动布局无效果
    UIViewAutoresizingNone                 = 0,
    //自动调整与superView左边的距离，保证与superView右边的距离不变。
    UIViewAutoresizingFlexibleLeftMargin   = 1 << 0,
    //自动调整自己的宽度，保证与superView左边和右边的距离不变。
    UIViewAutoresizingFlexibleWidth        = 1 << 1,
    //自动调整与superView的右边距离，保证与superView左边的距离不变。
    UIViewAutoresizingFlexibleRightMargin  = 1 << 2,
    //自动调整与superView顶部的距离，保证与superView底部的距离不变。
    UIViewAutoresizingFlexibleTopMargin    = 1 << 3,
    //自动调整自己的高度，保证与superView顶部和底部的距离不变。
    UIViewAutoresizingFlexibleHeight       = 1 << 4,
    //自动调整与superView底部的距离，也就是说，与superView顶部的距离不变。
    UIViewAutoresizingFlexibleBottomMargin = 1 << 5
    
    /** 注意点*/
    /*1>  在这里说明一下，如果是经常使用Storyboard/Xib设置autoresizing，那么转变使用代码设置autoresizing的话，容易出现理解错误问题。比如说UIViewAutoresizingFlexibleTopMargin，也许会被误认为是顶部距离不变，其实是底部距离不变。这个解决办法也很简单，只需要把使用代码和使用Storyboard设置autoresizing，它们是相反的，只需要这样去记就可以了。
     */
    
    /*
    2> autoresizing组合使用：
     
     也就是枚举中的值可以使用|隔开，同时拥有多个值的功能，可以针对不同的场景作不同的变化。例如：
     
     UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin
     意思是：view的宽度按照父视图的宽度比例进行缩放，距离父视图顶部距离不变。
     
     其它的组合类似，我这里就不一一列举了。
     */
};

//UIView选项枚举
typedef NS_OPTIONS(NSUInteger, UIViewAnimationOptions) {
    //提交动画的时候布局子控件，表示子控件将和父控件一同动画。
    UIViewAnimationOptionLayoutSubviews            = 1 <<  0,
    //动画时允许用户交流，比如触摸
    UIViewAnimationOptionAllowUserInteraction      = 1 <<  1, // turn on user interaction while animating
    //从当前状态开始动画
    UIViewAnimationOptionBeginFromCurrentState     = 1 <<  2, // start all views from current value, not initial value
    //动画无限重复
    UIViewAnimationOptionRepeat                    = 1 <<  3, // repeat animation indefinitely
    //执行动画回路,前提是设置动画无限重复
    UIViewAnimationOptionAutoreverse               = 1 <<  4, // if repeat, run animation back and forth
    //忽略外层动画嵌套的执行时间
    UIViewAnimationOptionOverrideInheritedDuration = 1 <<  5, // ignore nested duration
    //忽略外层动画嵌套的时间变化曲线
    UIViewAnimationOptionOverrideInheritedCurve    = 1 <<  6, // ignore nested curve
    //通过改变属性和重绘实现动画效果，如果key没有提交动画将使用快照
    UIViewAnimationOptionAllowAnimatedContent      = 1 <<  7, // animate contents (applies to transitions only)
    //用显隐的方式替代添加移除图层的动画效果
    UIViewAnimationOptionShowHideTransitionViews   = 1 <<  8, // flip to/from hidden state instead of adding/removing
    //1.忽略嵌套继承的选项   2.时间函数曲线相关
    UIViewAnimationOptionOverrideInheritedOptions  = 1 <<  9, // do not inherit any options or animation type
    //时间曲线函数，由慢到快
    UIViewAnimationOptionCurveEaseInOut            = 0 << 16, // default
    //时间曲线函数，由慢到特别快
    UIViewAnimationOptionCurveEaseIn               = 1 << 16,
    //时间曲线函数，由快到慢
    UIViewAnimationOptionCurveEaseOut              = 2 << 16,
    //时间曲线函数，匀速
    UIViewAnimationOptionCurveLinear               = 3 << 16,
    
    /*转场动画相关的**/
    //无转场动画
    UIViewAnimationOptionTransitionNone            = 0 << 20, // default
    //转场从左翻转
    UIViewAnimationOptionTransitionFlipFromLeft    = 1 << 20,
    //转场从右翻转
    UIViewAnimationOptionTransitionFlipFromRight   = 2 << 20,
    //上卷转场
    UIViewAnimationOptionTransitionCurlUp          = 3 << 20,
    //下卷转场
    UIViewAnimationOptionTransitionCurlDown        = 4 << 20,
    //转场交叉消失
    UIViewAnimationOptionTransitionCrossDissolve   = 5 << 20,
    //转场从上翻转
    UIViewAnimationOptionTransitionFlipFromTop     = 6 << 20,
    //转场从下翻转
    UIViewAnimationOptionTransitionFlipFromBottom  = 7 << 20,
    
    /** 使用场景*/
    //例子:[UIView transitionFromView: toView: duration: options: completion:^(BOOL finished) {}];
    
} NS_ENUM_AVAILABLE_IOS(4_0);

//
typedef NS_OPTIONS(NSUInteger, UIViewKeyframeAnimationOptions) {
    UIViewKeyframeAnimationOptionLayoutSubviews            = UIViewAnimationOptionLayoutSubviews,
    UIViewKeyframeAnimationOptionAllowUserInteraction      = UIViewAnimationOptionAllowUserInteraction, // turn on user interaction while animating
    UIViewKeyframeAnimationOptionBeginFromCurrentState     = UIViewAnimationOptionBeginFromCurrentState, // start all views from current value, not initial value
    UIViewKeyframeAnimationOptionRepeat                    = UIViewAnimationOptionRepeat, // repeat animation indefinitely
    UIViewKeyframeAnimationOptionAutoreverse               = UIViewAnimationOptionAutoreverse, // if repeat, run animation back and forth
    UIViewKeyframeAnimationOptionOverrideInheritedDuration = UIViewAnimationOptionOverrideInheritedDuration, // ignore nested duration
    UIViewKeyframeAnimationOptionOverrideInheritedOptions  = UIViewAnimationOptionOverrideInheritedOptions, // do not inherit any options or animation type
    
    UIViewKeyframeAnimationOptionCalculationModeLinear     = 0 << 10, // default
    UIViewKeyframeAnimationOptionCalculationModeDiscrete   = 1 << 10,
    UIViewKeyframeAnimationOptionCalculationModePaced      = 2 << 10,
    UIViewKeyframeAnimationOptionCalculationModeCubic      = 3 << 10,
    UIViewKeyframeAnimationOptionCalculationModeCubicPaced = 4 << 10
} NS_ENUM_AVAILABLE_IOS(7_0);

//系统动画枚举
typedef NS_ENUM(NSUInteger, UISystemAnimation) {
    //在动画完成时移除views
    UISystemAnimationDelete,    // removes the views from the hierarchy when complete
} NS_ENUM_AVAILABLE_IOS(7_0);

//UIView枚举tint color的调整模式
typedef NS_ENUM(NSInteger, UIViewTintAdjustmentMode) {
    //视图的着色调整模式与父视图一致
    UIViewTintAdjustmentModeAutomatic,
    //视图的tintColor属性返回完全未修改的视图着色颜色
    UIViewTintAdjustmentModeNormal,
    //视图的tintColor属性返回一个去饱和度的、变暗的视图着色颜色
    UIViewTintAdjustmentModeDimmed,
    
    /** 注意*/
    /*
     当tintAdjustmentMode属性设置为Dimmed时，tintColor的颜色值会自动变暗。而如果我们在视图层次结构中没有找到默认值，则该值默认是Normal。
     */
    
} NS_ENUM_AVAILABLE_IOS(7_0);

typedef NS_ENUM(NSInteger, UISemanticContentAttribute) {
    UISemanticContentAttributeUnspecified = 0,
    UISemanticContentAttributePlayback, // for playback controls such as Play/RW/FF buttons and playhead scrubbers
    UISemanticContentAttributeSpatial, // for controls that result in some sort of directional change in the UI, e.g. a segmented control for text alignment or a D-pad in a game
    UISemanticContentAttributeForceLeftToRight,
    UISemanticContentAttributeForceRightToLeft
} NS_ENUM_AVAILABLE_IOS(9_0);

typedef NS_ENUM(NSInteger, UIUserInterfaceLayoutDirection) {
    UIUserInterfaceLayoutDirectionLeftToRight,
    UIUserInterfaceLayoutDirectionRightToLeft,
} NS_ENUM_AVAILABLE_IOS(5_0);

@protocol UICoordinateSpace <NSObject>

- (CGPoint)convertPoint:(CGPoint)point toCoordinateSpace:(id <UICoordinateSpace>)coordinateSpace NS_AVAILABLE_IOS(8_0);
- (CGPoint)convertPoint:(CGPoint)point fromCoordinateSpace:(id <UICoordinateSpace>)coordinateSpace NS_AVAILABLE_IOS(8_0);
- (CGRect)convertRect:(CGRect)rect toCoordinateSpace:(id <UICoordinateSpace>)coordinateSpace NS_AVAILABLE_IOS(8_0);
- (CGRect)convertRect:(CGRect)rect fromCoordinateSpace:(id <UICoordinateSpace>)coordinateSpace NS_AVAILABLE_IOS(8_0);

@property (readonly, nonatomic) CGRect bounds NS_AVAILABLE_IOS(8_0);

@end

@class UIBezierPath, UIEvent, UIWindow, UIViewController, UIColor, UIGestureRecognizer, UIMotionEffect, CALayer, UILayoutGuide;

NS_CLASS_AVAILABLE_IOS(2_0) @interface UIView : UIResponder <NSCoding, UIAppearance, UIAppearanceContainer, UIDynamicItem, UITraitEnvironment, UICoordinateSpace, UIFocusEnvironment>

/*
 UIView有个layer属性，可以返回它的主CALayer实例，UIView有一个layerClass方法，返回主layer所使用的类，UIView的子类，可以通过重载这个方法，来让UIView使用不同的CALayer来显示。
 */
+ (Class)layerClass;                        // default is [CALayer class]. Used when creating the underlying layer for the view.

/** 初始化View并设置frame大小*/
- (instancetype)initWithFrame:(CGRect)frame NS_DESIGNATED_INITIALIZER;

/** 用于解码*/
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

/** 属性设置view是否支持触摸点击*/
@property(nonatomic,getter=isUserInteractionEnabled) BOOL userInteractionEnabled;  // default is YES. if set to NO, user events (touch, keys) are ignored and removed from the event queue.

/** 给view添加tag标签*/
@property(nonatomic)                                 NSInteger tag;                // default is 0

/** view的layer属性*/
@property(nonatomic,readonly,strong)                 CALayer  *layer;              // returns view's layer. Will always return a non-nil value. view is layer's delegate

/** 设置控件可以成为第一响应者*/
- (BOOL)canBecomeFocused NS_AVAILABLE_IOS(9_0); // NO by default
@property (readonly, nonatomic, getter=isFocused) BOOL focused NS_AVAILABLE_IOS(9_0);

+ (UIUserInterfaceLayoutDirection)userInterfaceLayoutDirectionForSemanticContentAttribute:(UISemanticContentAttribute)attribute NS_AVAILABLE_IOS(9_0);
@property (nonatomic) UISemanticContentAttribute semanticContentAttribute NS_AVAILABLE_IOS(9_0);
@end

@interface UIView(UIViewGeometry)

// animatable. do not use frame if view is transformed since it will not correctly reflect the actual location of the view. use bounds + center instead.

/** 位置和尺寸 以父控件的左上角为原点*/
@property(nonatomic) CGRect            frame;

// use bounds/center and not frame if non-identity transform. if bounds dimension is odd, center may be have fractional part

/** 位置和尺寸以自己的左上角为原点*/
@property(nonatomic) CGRect            bounds;      // default bounds is zero origin, frame size. animatable

/** 中点 以父控件的左上角为原点*/
@property(nonatomic) CGPoint           center;      // center is center of frame. animatable

/** 形变属性 缩放 旋转*/
@property(nonatomic) CGAffineTransform transform;   // default is CGAffineTransformIdentity. animatable

/** */
@property(nonatomic) CGFloat           contentScaleFactor NS_AVAILABLE_IOS(4_0);

/** 返回值决定是否支持多点触摸*/
@property(nonatomic,getter=isMultipleTouchEnabled) BOOL multipleTouchEnabled __TVOS_PROHIBITED;   // default is NO

/** 如果设置为YES则当前UIView会独占整个Touch事件。具体来说就是如果UIView设置了exclusiveTouch属性为YES则当这个UIView成为第一响应者时，在手指离开屏幕前其他view不会相应任何touch事件.*/
@property(nonatomic,getter=isExclusiveTouch) BOOL       exclusiveTouch __TVOS_PROHIBITED;         // default is NO

/** 当在一个view上添加一个屏幕罩时，但又不影响对下面view的操作，也就是可以通过屏幕罩对下面的view进行操作。*/
- (nullable UIView *)hitTest:(CGPoint)point withEvent:(nullable UIEvent *)event;   // recursively calls -pointInside:withEvent:. point is in the receiver's coordinate system

/** 这个函数的用处是判断当前的点击或者触摸事件的点是否在当前的view中。*/
- (BOOL)pointInside:(CGPoint)point withEvent:(nullable UIEvent *)event;   // default returns YES if point is in bounds

/** 转换一个点从接受者坐标系到给定视图坐标系*/
- (CGPoint)convertPoint:(CGPoint)point toView:(nullable UIView *)view;

/** 把一个点从一个坐标系转换到接收者的坐标系*/
- (CGPoint)convertPoint:(CGPoint)point fromView:(nullable UIView *)view;

/** 转换接收者坐标系中的矩形到其他视图*/
- (CGRect)convertRect:(CGRect)rect toView:(nullable UIView *)view;

/** 转换一个矩形从其他视图坐标系到接收者坐标系*/
- (CGRect)convertRect:(CGRect)rect fromView:(nullable UIView *)view;

/** 如果某个视图的这个属性被设置为YES，则其子视图会根据autoresizingMask属性的值自动进行尺寸调整，简单配置一下视图的自动尺寸调整掩码常常就能使应用程序得到合适的行为。否则，应用程序就必须通过重载layoutSubviews方法来提供自己的实现*/
@property(nonatomic) BOOL               autoresizesSubviews; // default is YES. if set, subviews are adjusted according to their autoresizingMask if self.bounds changes

/** 自动调整子控件与父控件中间的位置，宽高*/
@property(nonatomic) UIViewAutoresizing autoresizingMask;    // simple resize. default is UIViewAutoresizingNone

/** 这个方法会计算并且返回一个最适应接收子视图的大小*/
- (CGSize)sizeThatFits:(CGSize)size;     // return 'best' size to fit given size. does not actually resize view. Default is return existing view size

/** 移动并且调整子视图的大小*/
- (void)sizeToFit;                       // calls sizeThatFits: with current view bounds and changes bounds size.

@end

@interface UIView(UIViewHierarchy)

/** 取到父view (只读)*/
@property(nullable, nonatomic,readonly) UIView       *superview;

/** 取到view的子view (只读)*/
@property(nonatomic,readonly,copy) NSArray<__kindof UIView *> *subviews;

/** 屏幕窗口 (只读)*/
@property(nullable, nonatomic,readonly) UIWindow     *window;

/** 把当前视图从它的父控件视图中移除*/
- (void)removeFromSuperview;

/** 在视图中插入一个视图，并且可以设置索引值*/
- (void)insertSubview:(UIView *)view atIndex:(NSInteger)index;

/** 交换指定位置的两个视图的位置*/
- (void)exchangeSubviewAtIndex:(NSInteger)index1 withSubviewAtIndex:(NSInteger)index2;

/** 增加一个子视图控件，新添加的控件默认都是在subviews数组的后面，也就是默认显示在最上面*/
- (void)addSubview:(UIView *)view;

/** 增加一个子控件，插入到siblingSubview的下面*/
- (void)insertSubview:(UIView *)view belowSubview:(UIView *)siblingSubview;

/** 增加一个子控件，插入到siblingSubview的上面*/
- (void)insertSubview:(UIView *)view aboveSubview:(UIView *)siblingSubview;

/** 将一个指定的控件拖动到最上面来显示*/
- (void)bringSubviewToFront:(UIView *)view;

/** 将一个指定的控件拖动到最下面来显示*/
- (void)sendSubviewToBack:(UIView *)view;

/** 告诉视图子视图已经添加，默认不执行任何操作，子类可以重写*/
- (void)didAddSubview:(UIView *)subview;

/** 通知视图某个子视图即将被移除，默认不执行任何操作，子类可以重写*/
- (void)willRemoveSubview:(UIView *)subview;

/** 通知即将移动到新的父视图中*/
- (void)willMoveToSuperview:(nullable UIView *)newSuperview;

/** 通知已经移动到新的父视图*/
- (void)didMoveToSuperview;

/** 通知即将已移动到新的窗口*/
- (void)willMoveToWindow:(nullable UIWindow *)newWindow;

/** 通知已经移动到新的窗口*/
- (void)didMoveToWindow;

/** 返回一个布尔值 判断某个视图是否view的子控件或者子控件的子控件*/
- (BOOL)isDescendantOfView:(UIView *)view;  // returns YES for self.

/** 通过tag获得对应tag的子控件*/
- (nullable __kindof UIView *)viewWithTag:(NSInteger)tag; // recursive search. includes self

// Allows you to perform layout before the drawing cycle happens. -layoutIfNeeded forces layout early
/** 在对现在有布局有调整更改后，使用这个方法进行更新.*/
- (void)setNeedsLayout;

/** 强制进行更新layout，通常与上面的方法结合一块使用.*/
- (void)layoutIfNeeded;

/** 一般写在view内部，当控件的大小约束发生变化的时候在这里重写布局子控件的位置和尺寸，一般在这个方法里面或者视图的frame是最准确的.*/
- (void)layoutSubviews;    // override point. called by layoutIfNeeded automatically. As of iOS 6.0, when constraints-based layout is used the base implementation applies the constraints-based layout, otherwise it does nothing.

/*
 -layoutMargins returns a set of insets from the edge of the view's bounds that denote a default spacing for laying out content.
 If preservesSuperviewLayoutMargins is YES, margins cascade down the view tree, adjusting for geometry offsets, so that setting the left value of layoutMargins on a superview will affect the left value of layoutMargins for subviews positioned close to the left edge of their superview's bounds
 If your view subclass uses layoutMargins in its layout or drawing, override -layoutMarginsDidChange in order to refresh your view if the margins change.
 */

/** iOS8的新特性，我们可以用这个属性去定义view之间的间距，该属性只对autolayout布局有效。*/
@property (nonatomic) UIEdgeInsets layoutMargins NS_AVAILABLE_IOS(8_0);

/** preservesSuperviewLayoutMargins这个属性默认是NO，如果把它设为YES，layoutMargins会根据屏幕中相关view的布局而改变。*/
@property (nonatomic) BOOL preservesSuperviewLayoutMargins NS_AVAILABLE_IOS(8_0); // default is NO - set to enable pass-through or cascading behavior of margins from this view’s parent to its children

/** 在我们改变view的layoutMargins这个属性时，会触发这个方法，我们在自己的view里面可以重写这个方法来捕获layoutMargins的变化。在大多数情况下，我们可以在这个方法里面触发drawing和layout的update。*/
- (void)layoutMarginsDidChange NS_AVAILABLE_IOS(8_0);

/* The edges of this guide are constrained to equal the edges of the view inset by the layoutMargins
 */

/** 自动布局*/
@property(readonly,strong) UILayoutGuide *layoutMarginsGuide NS_AVAILABLE_IOS(9_0);

/// This content guide provides a layout area that you can use to place text and related content whose width should generally be constrained to a size that is easy for the user to read. This guide provides a centered region that you can place content within to get this behavior for this view.

/** 这是因为iOS 9为 UIView 引入了一个新的属性 readableContentGuide ，这个属性为View定义了一个可以放置用于阅读的内容的最佳区域。如果启用 readableContentGuide 的话，那么View就会把它作为边缘进行布局。但是这可能并不是我们想要的效果，要关闭TableView的Readable Content Guide，可以在 viewDidLoad: 中调用下面这段代码：
 
 // 在viewDidLoad:中调用：
 if #available(iOS 9.0, *) 
 {
   tableView.cellLayoutMarginsFollowReadableWidth = false
 }
 */
@property (nonatomic, readonly, strong) UILayoutGuide *readableContentGuide  NS_AVAILABLE_IOS(9_0);
@end

@interface UIView(UIViewRendering)

/** 如果我们想要在一个UIView中绘图，需要写一个扩展UIView的类，并重写drawRect方法，在这里进行绘图操作。这个方法不能直接调用。苹果要求我们调用UIView类中的setNeedsDisplay方法，则程序会自动调用drawRect方法进行重回（调用setNeedsDisplay会自动调用drawRect）*/
- (void)drawRect:(CGRect)rect;


/** 调用这个方法会自动调用drawRect方法*/
- (void)setNeedsDisplay;

/** 同上，直接调用setNeedsDisplay，或者setNeedsDisplayInRect触发drawRect，但是有个前提条件是rect不能为0*/
- (void)setNeedsDisplayInRect:(CGRect)rect;

/** 当时YES的时候，如果子视图的范围超出了父视图的边界，那么超出的部分就会被裁剪掉。*/
@property(nonatomic)                 BOOL              clipsToBounds;              // When YES, content and subviews are clipped to the bounds of the view. Default is NO.

/** view的背景颜色*/
@property(nullable, nonatomic,copy)            UIColor          *backgroundColor UI_APPEARANCE_SELECTOR; // default is nil. Can be useful with the appearance proxy on custom UIView subclasses.

/** 透明度*/
@property(nonatomic)                 CGFloat           alpha;                      // animatable. default is 1.0

/** 不透明度*/
@property(nonatomic,getter=isOpaque) BOOL              opaque;                     // default is YES. opaque views must fill their entire bounds or the results are undefined. the active CGContext in drawRect: will not have been cleared and may have non-zeroed pixels

/** 如果设置为YES,在view请求之前都会清楚current context buffer(状态)，来更新相同区域*/
@property(nonatomic)                 BOOL              clearsContextBeforeDrawing; // default is YES. ignored for opaque views. for non-opaque views causes the active CGContext in drawRect: to be pre-filled with transparent pixels

/** 隐藏*/
@property(nonatomic,getter=isHidden) BOOL              hidden;                     // default is NO. doesn't check superviews

/** 内容显示的模式*/
@property(nonatomic)                 UIViewContentMode contentMode;                // default is UIViewContentModeScaleToFill

/** 图片的拉伸操作例如
 imageView.image = [UIImage imageNamed:@"image.png"]; 
 [imageView setContentStretch:CGRectMake(150.0/300.0,75.0/150.0,10.0/300.0,10.0/150.0)];
 
 image.png的大小是 210.0  x  126.0；
 imageView的frame是（9，117，300，150）；
 
 150.0/300.0表示x轴上，前150个像素不进行拉伸。
 75.0/150.0表示y轴上，前75个像素不进行拉伸。
 10.0/300.0表示x轴上150后的10个像素（151-160）进行拉伸，直到image.png铺满imageView。
 10.0/150.0表示y轴上75后的10个（76-85）像素进行拉伸，直到image.png铺满imageView。*/
@property(nonatomic)                 CGRect            contentStretch NS_DEPRECATED_IOS(3_0,6_0) __TVOS_PROHIBITED; // animatable. default is unit rectangle {{0,0} {1,1}}. Now deprecated: please use -[UIImage resizableImageWithCapInsets:] to achieve the same effect.

/** 蒙板view*/
@property(nullable, nonatomic,strong)          UIView           *maskView NS_AVAILABLE_IOS(8_0);

/*
 -tintColor always returns a color. The color returned is the first non-default value in the receiver's superview chain (starting with itself).
 If no non-default value is found, a system-defined color is returned.
 If this view's -tintAdjustmentMode returns Dimmed, then the color that is returned for -tintColor will automatically be dimmed.
 If your view subclass uses tintColor in its rendering, override -tintColorDidChange in order to refresh the rendering if the color changes.
 */

/**   这个属性使用是改变应用程序的外观的。默认tintColor的值为nil，这表示它将会运用父视图层次的颜色来进行着色。如果父视图中没有设置tintColor，那么默认系统就会使用蓝色。因此，可以通过root view controller的tintColor来改变系统整体的颜色。*/
@property(null_resettable, nonatomic, strong) UIColor *tintColor NS_AVAILABLE_IOS(7_0);

/*
 -tintAdjustmentMode always returns either UIViewTintAdjustmentModeNormal or UIViewTintAdjustmentModeDimmed. The value returned is the first non-default value in the receiver's superview chain (starting with itself).
 If no non-default value is found, UIViewTintAdjustmentModeNormal is returned.
 When tintAdjustmentMode has a value of UIViewTintAdjustmentModeDimmed for a view, the color it returns from tintColor will be modified to give a dimmed appearance.
 When the tintAdjustmentMode of a view changes (either the view's value changing or by one of its superview's values changing), -tintColorDidChange will be called to allow the view to refresh its rendering.
 */

/** 这个属性可以使tintColor变暗，因此整个视图层次变暗。并且它有三个值在里面选择一个设置。*/
@property(nonatomic) UIViewTintAdjustmentMode tintAdjustmentMode NS_AVAILABLE_IOS(7_0);

/*
 The -tintColorDidChange message is sent to appropriate subviews of a view when its tintColor is changed by client code or to subviews in the view hierarchy of a view whose tintColor is implicitly changed when its superview or tintAdjustmentMode changes.
 */

/** 覆盖这个方法的目的是为了当tintColor改变的时候自定义一些行为。*/
- (void)tintColorDidChange NS_AVAILABLE_IOS(7_0);

@end

@interface UIView(UIViewAnimation)

/** 开始动画*/
+ (void)beginAnimations:(nullable NSString *)animationID context:(nullable void *)context;  // additional context info passed to will start/did stop selectors. begin/commit can be nested

/** 提交动画*/
+ (void)commitAnimations;                                                 // starts up any animations when the top level animation is commited

/** 设置动画代理*/
// no getters. if called outside animation block, these setters have no effect.
+ (void)setAnimationDelegate:(nullable id)delegate;                          // default = nil

/** 动画将要开始时执行方法（必须要先设置动画代理）*/
+ (void)setAnimationWillStartSelector:(nullable SEL)selector;                // default = NULL. -animationWillStart:(NSString *)animationID context:(void *)context

/** 动画已结束时执行方法（必须要先设置动画代理）*/
+ (void)setAnimationDidStopSelector:(nullable SEL)selector;                  // default = NULL. -animationDidStop:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context

/** 设置动画时长*/
+ (void)setAnimationDuration:(NSTimeInterval)duration;              // default = 0.2

/** 动画延迟执行时间*/
+ (void)setAnimationDelay:(NSTimeInterval)delay;                    // default = 0.0

/** 设置在动画块内部动画属性(数据)改变的开始时间*/
+ (void)setAnimationStartDate:(NSDate *)startDate;                  // default = now ([NSDate date])

/** 设置动画曲线，默认是匀速进行*/
+ (void)setAnimationCurve:(UIViewAnimationCurve)curve;              // default = UIViewAnimationCurveEaseInOut

/** 动画的重复播放此时*/
+ (void)setAnimationRepeatCount:(float)repeatCount;                 // default = 0.0.  May be fractional

/** 设置是否自定翻转当前的动画效果*/
+ (void)setAnimationRepeatAutoreverses:(BOOL)repeatAutoreverses;    // default = NO. used if repeat count is non-zero

/** 设置动画从当前状态开始播放*/
+ (void)setAnimationBeginsFromCurrentState:(BOOL)fromCurrentState;  // default = NO. If YES, the current view position is always used for new animations -- allowing animations to "pile up" on each other. Otherwise, the last end state is used for the animation (the default).

/** 在动画块中为视图设置过渡*/
+ (void)setAnimationTransition:(UIViewAnimationTransition)transition forView:(UIView *)view cache:(BOOL)cache;  // current limitation - only one per begin/commit block

/** 设置是否激活动画*/
+ (void)setAnimationsEnabled:(BOOL)enabled;                         // ignore any attribute changes while set.

/** 返回一个布尔值表示所有动画是否结束*/
+ (BOOL)areAnimationsEnabled;

/** 先检查动画当前是否启用，然后禁止动画，执行block内的方法，最后重新启用动画，而且这个方法不会阻塞基于CoreAnimation的动画*/
+ (void)performWithoutAnimation:(void (^)(void))actionsWithoutAnimation NS_AVAILABLE_IOS(7_0);

+ (NSTimeInterval)inheritedAnimationDuration NS_AVAILABLE_IOS(9_0);

@end

/** UIView动画与Blocks*/
@interface UIView(UIViewAnimationWithBlocks)

/** block封装参与动画  动画时长 延迟时间 动画选项条件 动画结束的回调*/
+ (void)animateWithDuration:(NSTimeInterval)duration delay:(NSTimeInterval)delay options:(UIViewAnimationOptions)options animations:(void (^)(void))animations completion:(void (^ __nullable)(BOOL finished))completion NS_AVAILABLE_IOS(4_0);

/** block封装参与动画 动画时长 动画结束的回调*/
+ (void)animateWithDuration:(NSTimeInterval)duration animations:(void (^)(void))animations completion:(void (^ __nullable)(BOOL finished))completion NS_AVAILABLE_IOS(4_0); // delay = 0.0, options = 0

/** block封装参与动画  动画时长*/
+ (void)animateWithDuration:(NSTimeInterval)duration animations:(void (^)(void))animations NS_AVAILABLE_IOS(4_0); // delay = 0.0, options = 0, completion = NULL

/* Performs `animations` using a timing curve described by the motion of a spring. When `dampingRatio` is 1, the animation will smoothly decelerate to its final model values without oscillating. Damping ratios less than 1 will oscillate more and more before coming to a complete stop. You can use the initial spring velocity to specify how fast the object at the end of the simulated spring was moving before it was attached. It's a unit coordinate system, where 1 is defined as travelling the total animation distance in a second. So if you're changing an object's position by 200pt in this animation, and you want the animation to behave as if the object was moving at 100pt/s before the animation started, you'd pass 0.5. You'll typically want to pass 0 for the velocity. */ 

/** 弹性动画*/
+ (void)animateWithDuration:(NSTimeInterval)duration delay:(NSTimeInterval)delay usingSpringWithDamping:(CGFloat)dampingRatio initialSpringVelocity:(CGFloat)velocity options:(UIViewAnimationOptions)options animations:(void (^)(void))animations completion:(void (^ __nullable)(BOOL finished))completion NS_AVAILABLE_IOS(7_0);

/** 参数解析:
 
 duration：动画的持续时间
 
 view：需要进行转场动画的视图
 
 options：转场动画的类型
 
 animations：将改变视图属性的代码放在这个block中
 
 completion：动画结束后，会自动调用这个block
 */
+ (void)transitionWithView:(UIView *)view duration:(NSTimeInterval)duration options:(UIViewAnimationOptions)options animations:(void (^ __nullable)(void))animations completion:(void (^ __nullable)(BOOL finished))completion NS_AVAILABLE_IOS(4_0);

/** 方法调用完毕后，相当于执行了下面两句代码：
 
 // 添加toView到父视图
 
 [fromView.superview addSubview:toView];
 
 // 把fromView从父视图中移除
 
 [fromView.superview removeFromSuperview];
 
 参数解析:
 
 duration：动画的持续时间
 
 options：转场动画的类型
 
 animations：将改变视图属性的代码放在这个block中
 
 completion：动画结束后，会自动调用这个block
 */
+ (void)transitionFromView:(UIView *)fromView toView:(UIView *)toView duration:(NSTimeInterval)duration options:(UIViewAnimationOptions)options completion:(void (^ __nullable)(BOOL finished))completion NS_AVAILABLE_IOS(4_0); // toView added to fromView.superview, fromView removed from its superview

/* Performs the requested system-provided animation on one or more views. Specify addtional animations in the parallelAnimations block. These additional animations will run alongside the system animation with the same timing and duration that the system animation defines/inherits. Additional animations should not modify properties of the view on which the system animation is being performed. Not all system animations honor all available options.
 */
+ (void)performSystemAnimation:(UISystemAnimation)animation onViews:(NSArray<__kindof UIView *> *)views options:(UIViewAnimationOptions)options animations:(void (^ __nullable)(void))parallelAnimations completion:(void (^ __nullable)(BOOL finished))completion NS_AVAILABLE_IOS(7_0);

@end

/** UIView动画组合*/
@interface UIView (UIViewKeyframeAnimations)

/** UIView添加了一个方法用来直接使用关键帧动画而不用辅助CoreAnimation来实现，这个方法需要浮点型的动画持续时长和延迟，一些二进制组成的选项和动画运行的block和动画运行完后最后的block，这是一个标准的UIVIew的动画的实现。*/
+ (void)animateKeyframesWithDuration:(NSTimeInterval)duration delay:(NSTimeInterval)delay options:(UIViewKeyframeAnimationOptions)options animations:(void (^)(void))animations completion:(void (^ __nullable)(BOOL finished))completion NS_AVAILABLE_IOS(7_0);

/** 这个方法是用来添加动画序列内的不动点。*/
+ (void)addKeyframeWithRelativeStartTime:(double)frameStartTime relativeDuration:(double)frameDuration animations:(void (^)(void))animations NS_AVAILABLE_IOS(7_0); // start time and duration are values between 0.0 and 1.0 specifying time and duration relative to the overall time of the keyframe animation

@end

/** UIView手势*/
@interface UIView (UIViewGestureRecognizers)

@property(nullable, nonatomic,copy) NSArray<__kindof UIGestureRecognizer *> *gestureRecognizers NS_AVAILABLE_IOS(3_2);

/** 添加手势*/
- (void)addGestureRecognizer:(UIGestureRecognizer*)gestureRecognizer NS_AVAILABLE_IOS(3_2);

/** 移除手势*/
- (void)removeGestureRecognizer:(UIGestureRecognizer*)gestureRecognizer NS_AVAILABLE_IOS(3_2);

// called when the recognizer attempts to transition out of UIGestureRecognizerStatePossible if a touch hit-tested to this view will be cancelled as a result of gesture recognition
// returns YES by default. return NO to cause the gesture recognizer to transition to UIGestureRecognizerStateFailed
// subclasses may override to prevent recognition of particular gestures. for example, UISlider prevents swipes parallel to the slider that start in the thumb

/** 询问一个手势接收者是否应该开始解释执行一个触摸接收事件  */
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer NS_AVAILABLE_IOS(6_0);

@end

/** UIView运动视觉效果*/
@interface UIView (UIViewMotionEffects)

/*! Begins applying `effect` to the receiver. The effect's emitted keyPath/value pairs will be
    applied to the view's presentation layer.
 
    Animates the transition to the motion effect's values using the present UIView animation
    context. */

/** 添加运动视觉效果*/
- (void)addMotionEffect:(UIMotionEffect *)effect NS_AVAILABLE_IOS(7_0);

/*! Stops applying `effect` to the receiver. Any affected presentation values will animate to
    their post-removal values using the present UIView animation context. */

/** 移除运动视觉效果*/
- (void)removeMotionEffect:(UIMotionEffect *)effect NS_AVAILABLE_IOS(7_0);

/** 运动视觉数组*/
@property (copy, nonatomic) NSArray<__kindof UIMotionEffect *> *motionEffects NS_AVAILABLE_IOS(7_0);

@end


//
// UIView Constraint-based Layout Support
//

/** 自动布局枚举*/
typedef NS_ENUM(NSInteger, UILayoutConstraintAxis) {
    /** 水平*/
    UILayoutConstraintAxisHorizontal = 0,
    /** 垂直*/
    UILayoutConstraintAxisVertical = 1
};

// Installing Constraints

/* A constraint is typically installed on the closest common ancestor of the views involved in the constraint. 
 It is required that a constraint be installed on _a_ common ancestor of every view involved.  The numbers in a constraint are interpreted in the coordinate system of the view it is installed on.  A view is considered to be an ancestor of itself.
 */
@interface UIView (UIConstraintBasedLayoutInstallingConstraints)

/** 返回当前view中的所有constraints(只读)*/
@property(nonatomic,readonly) NSArray<__kindof NSLayoutConstraint *> *constraints NS_AVAILABLE_IOS(6_0);

/** 添加单个constraint*/
- (void)addConstraint:(NSLayoutConstraint *)constraint NS_AVAILABLE_IOS(6_0); // This method will be deprecated in a future release and should be avoided.  Instead, set NSLayoutConstraint's active property to YES.

/** 添加一组contraint*/
- (void)addConstraints:(NSArray<__kindof NSLayoutConstraint *> *)constraints NS_AVAILABLE_IOS(6_0); // This method will be deprecated in a future release and should be avoided.  Instead use +[NSLayoutConstraint activateConstraints:].

/** 移除单个contraint*/
- (void)removeConstraint:(NSLayoutConstraint *)constraint NS_AVAILABLE_IOS(6_0); // This method will be deprecated in a future release and should be avoided.  Instead set NSLayoutConstraint's active property to NO.

/** 移除一组contraint*/
- (void)removeConstraints:(NSArray<__kindof NSLayoutConstraint *> *)constraints NS_AVAILABLE_IOS(6_0); // This method will be deprecated in a future release and should be avoided.  Instead use +[NSLayoutConstraint deactivateConstraints:].
@end

// Core Layout Methods

/* To render a window, the following passes will occur, if necessary.  
 
 update constraints
 layout
 display
 
 Please see the conceptual documentation for a discussion of these methods.
 */

@interface UIView (UIConstraintBasedLayoutCoreMethods)

/*******autoLayout的布局过程是update constraints（uodateContraints）->layout subviews(layoutSubviews)->display(drawRect)这三步不是单向的，如果layout的过程中改变了constraint，就会触发update constraints，进行新的一轮迭代。我们在实际代码中，应该避免在此造成死循环 *******/

/** 我们可以调用这个方法触发update Constraints的操作。在NeedsUpdateContraints返回YES时，才能成功触发update Contraints的操作。我们不应该重写这个方法。*/
- (void)updateConstraintsIfNeeded NS_AVAILABLE_IOS(6_0); // Updates the constraints from the bottom up for the view hierarchy rooted at the receiver. UIWindow's implementation creates a layout engine if necessary first.

/** 自定义view时，我们应该重写这个方法来设置当前view布局的布局约束，重写这个方法时一定要调用[super updateContraints]*/
- (void)updateConstraints NS_AVAILABLE_IOS(6_0); // Override this to adjust your special constraints during a constraints update pass

/** 布局系统使用这个返回值来确定是否调用updateContraints*/
- (BOOL)needsUpdateConstraints NS_AVAILABLE_IOS(6_0);

/** 当一个自定义的view某一个属性的改变可能影响到界面布局，我们应该调用这个方法来告诉布局系统在未来某个时刻需要更新，系统会调用updateContraints去更新布局。*/
- (void)setNeedsUpdateConstraints NS_AVAILABLE_IOS(6_0);
@end

// Compatibility and Adoption

@interface UIView (UIConstraintBasedCompatibility) 

/* By default, the autoresizing mask on a view gives rise to constraints that fully determine 
 the view's position. This allows the auto layout system to track the frames of views whose 
 layout is controlled manually (through -setFrame:, for example).
 When you elect to position the view using auto layout by adding your own constraints, 
 you must set this property to NO. IB will do this for you.
 */

/** 我们在使用代码来写自己的约束布局代码时，必须设置当前view的translatesAutoresizingMaskIntoContraints为NO，否则无法工作。
 */
@property(nonatomic) BOOL translatesAutoresizingMaskIntoConstraints NS_AVAILABLE_IOS(6_0); // Default YES

/* constraint-based layout engages lazily when someone tries to use it (e.g., adds a constraint to a view).  If you do all of your constraint set up in -updateConstraints, you might never even receive updateConstraints if no one makes a constraint.  To fix this chicken and egg problem, override this method to return YES if your view needs the window to use constraint-based layout.  
 */

/** 要求约束基于布局*/
+ (BOOL)requiresConstraintBasedLayout NS_AVAILABLE_IOS(6_0);

@end

// Separation of Concerns

@interface UIView (UIConstraintBasedLayoutLayering)

/* Constraints do not actually relate the frames of the views, rather they relate the "alignment rects" of views.  This is the same as the frame unless overridden by a subclass of UIView.  Alignment rects are the same as the "layout rects" shown in Interface Builder 3.  Typically the alignment rect of a view is what the end user would think of as the bounding rect around a control, omitting ornamentation like shadows and engraving lines.  The edges of the alignment rect are what is interesting to align, not the shadows and such.  
 */

/* These two methods should be inverses of each other.  UIKit will call both as part of layout computation.
 They may be overridden to provide arbitrary transforms between frame and alignment rect, though the two methods must be inverses of each other.
 However, the default implementation uses -alignmentRectInsets, so just override that if it's applicable.  It's easier to get right. 
 A view that displayed an image with some ornament would typically override these, because the ornamental part of an image would scale up with the size of the frame.  
 Set the NSUserDefault UIViewShowAlignmentRects to YES to see alignment rects drawn.
 */

/** 返回给定框架的视图的对齐矩阵*/
- (CGRect)alignmentRectForFrame:(CGRect)frame NS_AVAILABLE_IOS(6_0);

/** 返回给定对齐矩形的视图的frame*/
- (CGRect)frameForAlignmentRect:(CGRect)alignmentRect NS_AVAILABLE_IOS(6_0);

/* override this if the alignment rect is obtained from the frame by insetting each edge by a fixed amount.  This is only called by alignmentRectForFrame: and frameForAlignmentRect:.
 */

/** 返回从视图的frame上定义的对齐矩阵的边框*/
- (UIEdgeInsets)alignmentRectInsets NS_AVAILABLE_IOS(6_0);

/** 返回满足基线约束条件的视图*/
- (UIView *)viewForBaselineLayout NS_DEPRECATED_IOS(6_0, 9_0, "Override -viewForFirstBaselineLayout or -viewForLastBaselineLayout as appropriate, instead") __TVOS_PROHIBITED;

/* -viewForFirstBaselineLayout is called by the constraints system when interpreting
 the firstBaseline attribute for a view.
    For complex custom UIView subclasses, override this method to return the text-based
 (i.e., UILabel or non-scrollable UITextView) descendant of the receiver whose first baseline
 is appropriate for alignment.
    UIView's implementation returns [self viewForLastBaselineLayout], so if the same 
 descendant is appropriate for both first- and last-baseline layout you may override
 just -viewForLastBaselineLayout.
 */

@property(readonly,strong) UIView *viewForFirstBaselineLayout NS_AVAILABLE_IOS(9_0);

/* -viewForLastBaselineLayout is called by the constraints system when interpreting
 the lastBaseline attribute for a view.
    For complex custom UIView subclasses, override this method to return the text-based
 (i.e., UILabel or non-scrollable UITextView) descendant of the receiver whose last baseline
 is appropriate for alignment.
    UIView's implementation returns self.
 */
@property(readonly,strong) UIView *viewForLastBaselineLayout NS_AVAILABLE_IOS(9_0);

/* Override this method to tell the layout system that there is something it doesn't natively understand in this view, and this is how large it intrinsically is.  A typical example would be a single line text field.  The layout system does not understand text - it must just be told that there's something in the view, and that that something will take a certain amount of space if not clipped.  
 
 In response, UIKit will set up constraints that specify (1) that the opaque content should not be compressed or clipped, (2) that the view prefers to hug tightly to its content. 
 
 A user of a view may need to specify the priority of these constraints.  For example, by default, a push button 
 -strongly wants to hug its content in the vertical direction (buttons really ought to be their natural height)
 -weakly hugs its content horizontally (extra side padding between the title and the edge of the bezel is acceptable)
 -strongly resists compressing or clipping content in both directions. 
 
 However, you might have a case where you'd prefer to show all the available buttons with truncated text rather than losing some of the buttons. The truncation might only happen in portrait orientation but not in landscape, for example. In that case you'd want to setContentCompressionResistancePriority:forAxis: to (say) UILayoutPriorityDefaultLow for the horizontal axis.
 
 The default 'strong' and 'weak' priorities referred to above are UILayoutPriorityDefaultHigh and UILayoutPriorityDefaultLow.  
 
 Note that not all views have an intrinsicContentSize.  UIView's default implementation is to return (UIViewNoIntrinsicMetric, UIViewNoIntrinsicMetric).  The _intrinsic_ content size is concerned only with data that is in the view itself, not in other views. Remember that you can also set constant width or height constraints on any view, and you don't need to override instrinsicContentSize if these dimensions won't be changing with changing view content.
 */
UIKIT_EXTERN const CGFloat UIViewNoIntrinsicMetric NS_AVAILABLE_IOS(6_0); // -1

/** 返回接收对象的原本大小*/
- (CGSize)intrinsicContentSize NS_AVAILABLE_IOS(6_0);

/** 废除视图原本内容的size*/
- (void)invalidateIntrinsicContentSize NS_AVAILABLE_IOS(6_0); // call this when something changes that affects the intrinsicContentSize.  Otherwise UIKit won't notice that it changed.  

/** 与上边相反是视图的放大改变方式*/
- (UILayoutPriority)contentHuggingPriorityForAxis:(UILayoutConstraintAxis)axis NS_AVAILABLE_IOS(6_0);

/** 设置与上边相反是视图的放大改变方式*/
- (void)setContentHuggingPriority:(UILayoutPriority)priority forAxis:(UILayoutConstraintAxis)axis NS_AVAILABLE_IOS(6_0);

/** 设置当视图要变小时，视图的压缩改变方式，是水平缩小还是垂直缩小，并返回一个优先权*/
- (UILayoutPriority)contentCompressionResistancePriorityForAxis:(UILayoutConstraintAxis)axis NS_AVAILABLE_IOS(6_0);

/** 设置优先权*/
- (void)setContentCompressionResistancePriority:(UILayoutPriority)priority forAxis:(UILayoutConstraintAxis)axis NS_AVAILABLE_IOS(6_0);
@end

// Size To Fit

UIKIT_EXTERN const CGSize UILayoutFittingCompressedSize NS_AVAILABLE_IOS(6_0);
UIKIT_EXTERN const CGSize UILayoutFittingExpandedSize NS_AVAILABLE_IOS(6_0);

@interface UIView (UIConstraintBasedLayoutFittingSize)
/* The size fitting most closely to targetSize in which the receiver's subtree can be laid out while optimally satisfying the constraints. If you want the smallest possible size, pass UILayoutFittingCompressedSize; for the largest possible size, pass UILayoutFittingExpandedSize.
 Also see the comment for UILayoutPriorityFittingSizeLevel.
 */

/** 返回最合适的尺寸*/
- (CGSize)systemLayoutSizeFittingSize:(CGSize)targetSize NS_AVAILABLE_IOS(6_0); // Equivalent to sending -systemLayoutSizeFittingSize:withHorizontalFittingPriority:verticalFittingPriority: with UILayoutPriorityFittingSizeLevel for both priorities.

/** 返回最合适的水平或垂直尺寸(分优先级)*/
- (CGSize)systemLayoutSizeFittingSize:(CGSize)targetSize withHorizontalFittingPriority:(UILayoutPriority)horizontalFittingPriority verticalFittingPriority:(UILayoutPriority)verticalFittingPriority NS_AVAILABLE_IOS(8_0);
@end

@interface UIView (UILayoutGuideSupport)

/* UILayoutGuide objects owned by the receiver.
 */
@property(nonatomic,readonly,copy) NSArray<__kindof UILayoutGuide *> *layoutGuides NS_AVAILABLE_IOS(9_0);

/* Adds layoutGuide to the receiver, passing the receiver in -setOwningView: to layoutGuide.
 */
- (void)addLayoutGuide:(UILayoutGuide *)layoutGuide NS_AVAILABLE_IOS(9_0);

/* Removes layoutGuide from the receiver, passing nil in -setOwningView: to layoutGuide.
 */
- (void)removeLayoutGuide:(UILayoutGuide *)layoutGuide NS_AVAILABLE_IOS(9_0);
@end

@class NSLayoutXAxisAnchor,NSLayoutYAxisAnchor,NSLayoutDimension;
@interface UIView (UIViewLayoutConstraintCreation)
/* Constraint creation conveniences. See NSLayoutAnchor.h for details.
 */
@property(readonly, strong) NSLayoutXAxisAnchor *leadingAnchor NS_AVAILABLE_IOS(9_0);
@property(readonly, strong) NSLayoutXAxisAnchor *trailingAnchor NS_AVAILABLE_IOS(9_0);
@property(readonly, strong) NSLayoutXAxisAnchor *leftAnchor NS_AVAILABLE_IOS(9_0);
@property(readonly, strong) NSLayoutXAxisAnchor *rightAnchor NS_AVAILABLE_IOS(9_0);
@property(readonly, strong) NSLayoutYAxisAnchor *topAnchor NS_AVAILABLE_IOS(9_0);
@property(readonly, strong) NSLayoutYAxisAnchor *bottomAnchor NS_AVAILABLE_IOS(9_0);
@property(readonly, strong) NSLayoutDimension *widthAnchor NS_AVAILABLE_IOS(9_0);
@property(readonly, strong) NSLayoutDimension *heightAnchor NS_AVAILABLE_IOS(9_0);
@property(readonly, strong) NSLayoutXAxisAnchor *centerXAnchor NS_AVAILABLE_IOS(9_0);
@property(readonly, strong) NSLayoutYAxisAnchor *centerYAnchor NS_AVAILABLE_IOS(9_0);
@property(readonly, strong) NSLayoutYAxisAnchor *firstBaselineAnchor NS_AVAILABLE_IOS(9_0);
@property(readonly, strong) NSLayoutYAxisAnchor *lastBaselineAnchor NS_AVAILABLE_IOS(9_0);

@end

// Debugging

/* Everything in this section should be used in debugging only, never in shipping code.  These methods may not exist in the future - no promises.  
 */
@interface UIView (UIConstraintBasedLayoutDebugging)

/* This returns a list of all the constraints that are affecting the current location of the receiver.  The constraints do not necessarily involve the receiver, they may affect the frame indirectly.
 Pass UILayoutConstraintAxisHorizontal for the constraints affecting [self center].x and CGRectGetWidth([self bounds]), and UILayoutConstraintAxisVertical for the constraints affecting[self center].y and CGRectGetHeight([self bounds]).
 */
- (NSArray<__kindof NSLayoutConstraint *> *)constraintsAffectingLayoutForAxis:(UILayoutConstraintAxis)axis NS_AVAILABLE_IOS(6_0);

/* If there aren't enough constraints in the system to uniquely determine layout, we say the layout is ambiguous.  For example, if the only constraint in the system was x = y + 100, then there are lots of different possible values for x and y.  This situation is not automatically detected by UIKit, due to performance considerations and details of the algorithm used for layout.  
 The symptom of ambiguity is that views sometimes jump from place to place, or possibly are just in the wrong place.
 -hasAmbiguousLayout runs a check for whether there is another center and bounds the receiver could have that could also satisfy the constraints.
 -exerciseAmbiguousLayout does more.  It randomly changes the view layout to a different valid layout.  Making the UI jump back and forth can be helpful for figuring out where you're missing a constraint.  
 */

/** 视图的位置是否不完全指定*/
- (BOOL)hasAmbiguousLayout NS_AVAILABLE_IOS(6_0);

/** 在不同的有效值之间用一个模糊的布局随机改变视图的frame*/
- (void)exerciseAmbiguityInLayout NS_AVAILABLE_IOS(6_0); 
@end

@interface UIView (UIStateRestoration)
@property (nullable, nonatomic, copy) NSString *restorationIdentifier NS_AVAILABLE_IOS(6_0);

/** 编码视图的状态信息*/
- (void) encodeRestorableStateWithCoder:(NSCoder *)coder NS_AVAILABLE_IOS(6_0);

/** 解码一个视图状态信息*/
- (void) decodeRestorableStateWithCoder:(NSCoder *)coder NS_AVAILABLE_IOS(6_0);
@end

@interface UIView (UISnapshotting)
/* 
* When requesting a snapshot, 'afterUpdates' defines whether the snapshot is representative of what's currently on screen or if you wish to include any recent changes before taking the snapshot. 
 
 If called during layout from a committing transaction, snapshots occurring after the screen updates will include all changes made, regardless of when the snapshot is taken and the changes are made. For example:
 
     - (void)layoutSubviews {
         UIView *snapshot = [self snapshotViewAfterScreenUpdates:YES];
         self.alpha = 0.0;
     }
 
 The snapshot will appear to be empty since the change in alpha will be captured by the snapshot. If you need to animate the view during layout, animate the snapshot instead.

* Creating snapshots from existing snapshots (as a method to duplicate, crop or create a resizable variant) is supported. In cases where many snapshots are needed, creating a snapshot from a common superview and making subsequent snapshots from it can be more performant. Please keep in mind that if 'afterUpdates' is YES, the original snapshot is committed and any changes made to it, not the view originally snapshotted, will be included.
 */

/** 复制一个复合视图
 
 afterUpdates    是否视图展示时才生成视图
 No              会立即生成快照，并不会调用重新设置颜色的方法无色
 YES             当调用这个视图时生成
 
 */
- (UIView *)snapshotViewAfterScreenUpdates:(BOOL)afterUpdates NS_AVAILABLE_IOS(7_0);

/** 复制一个指定范围偏移量的复合视图*/
- (UIView *)resizableSnapshotViewFromRect:(CGRect)rect afterScreenUpdates:(BOOL)afterUpdates withCapInsets:(UIEdgeInsets)capInsets NS_AVAILABLE_IOS(7_0);  // Resizable snapshots will default to stretching the center
// Use this method to render a snapshot of the view hierarchy into the current context. Returns NO if the snapshot is missing image data, YES if the snapshot is complete. Calling this method from layoutSubviews while the current transaction is committing will capture what is currently displayed regardless if afterUpdates is YES.

/**  是否将指定范围的视图绘制到图形上下文中*/
- (BOOL)drawViewHierarchyInRect:(CGRect)rect afterScreenUpdates:(BOOL)afterUpdates NS_AVAILABLE_IOS(7_0);
@end

NS_ASSUME_NONNULL_END
