//
//  UIPageControl.h
//  UIKit
//
//  Copyright (c) 2008-2015 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIControl.h>
#import <UIKit/UIKitDefines.h>

NS_ASSUME_NONNULL_BEGIN

NS_CLASS_AVAILABLE_IOS(2_0) @interface UIPageControl : UIControl

//设置分页控制器上显示的页码总数(默认值是0)
@property(nonatomic) NSInteger numberOfPages;          // default is 0  默认值是0
//设置当前页码
@property(nonatomic) NSInteger currentPage;            // default is 0. value pinned to 0..numberOfPages-1 默认当前页码的页码数值是0.页码数的取值范围是从0--(总页数减1)
//设置只有一页的时候是否隐藏页码控制器
@property(nonatomic) BOOL hidesForSinglePage;          // hide the the indicator if there is only one page. default is NO  默认是NO,即单页时,默认是显示页码指示器的
//设置是否延迟更新当前页码
@property(nonatomic) BOOL defersCurrentPageDisplay;    // if set, clicking to a new page won't update the currently displayed page until -updateCurrentPageDisplay is called. default is NO  (默认值是NO)如果设置了YES,点击一个新的页码,当前页码也不会立马更行;直到手动调用-updateCurrentPageDisplay这个方法,页码才会genxin
- (void)updateCurrentPageDisplay;                      // update page display to match the currentPage. ignored if defersCurrentPageDisplay is NO. setting the page value directly will update immediately 会更新控制器的当前页码.但是如果defersCurrentPageDisplay的值是NO,则这个方法会被忽略.设置页码数就会立马更新

//通过传进来的页码数,返回页码控制器的大小
- (CGSize)sizeForNumberOfPages:(NSInteger)pageCount;   // returns minimum size required to display dots for given page count. can be used to size control if page count could change  会给页码控制器返回一个最小的尺寸,这个尺寸正好能够满足展现要求展现的页码数的.主要使用的情形:页码数会动态改变

//设置页码控制器中除当前页码外其他页码点的颜色
@property(nullable, nonatomic,strong) UIColor *pageIndicatorTintColor NS_AVAILABLE_IOS(6_0) UI_APPEARANCE_SELECTOR;
//设置页码控制器当前页码的页码点颜色
@property(nullable, nonatomic,strong) UIColor *currentPageIndicatorTintColor NS_AVAILABLE_IOS(6_0) UI_APPEARANCE_SELECTOR;

@end

NS_ASSUME_NONNULL_END
