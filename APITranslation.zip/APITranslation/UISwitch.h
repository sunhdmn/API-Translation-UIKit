//
//  UISwitch.h
//  UIKit
//
//  Copyright (c) 2008-2015 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIControl.h>
#import <UIKit/UIKitDefines.h>

NS_ASSUME_NONNULL_BEGIN

NS_CLASS_AVAILABLE_IOS(2_0) __TVOS_PROHIBITED @interface UISwitch : UIControl <NSCoding>

//设置开关在on状态下,开关显示颜色
@property(nullable, nonatomic, strong) UIColor *onTintColor NS_AVAILABLE_IOS(5_0) UI_APPEARANCE_SELECTOR;
//设置开关在off(关闭)状态下,开关显示的颜色
@property(null_resettable, nonatomic, strong) UIColor *tintColor NS_AVAILABLE_IOS(6_0);
//设置开关上按钮(即开关上的可滑动的小圆圈按钮)的颜色
@property(nullable, nonatomic, strong) UIColor *thumbTintColor NS_AVAILABLE_IOS(6_0) UI_APPEARANCE_SELECTOR;
//设置开关在on状态下,开关显示的图片（注意：在IOS7后不再起任何作用）
@property(nullable, nonatomic, strong) UIImage *onImage NS_AVAILABLE_IOS(6_0) UI_APPEARANCE_SELECTOR;
//设置开关在off状态下,开关显示的图片（注意：在IOS7后不再起任何作用）
@property(nullable, nonatomic, strong) UIImage *offImage NS_AVAILABLE_IOS(6_0) UI_APPEARANCE_SELECTOR;
//开关是否处于开启状态,是布尔类型的
@property(nonatomic,getter=isOn) BOOL on;
//设置控件的frame,即控件的大小和尺寸
- (instancetype)initWithFrame:(CGRect)frame NS_DESIGNATED_INITIALIZER;      // This class enforces a size appropriate for the control, and so the frame size is ignored.   UISwith这个类为控制器开关强制设置了一个合适的尺寸,所以用这个方法设置的尺寸是被系统忽略的(即不能自定义设置开关的尺寸)
//从Xib中加载
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;
//开关在on/off状态下是否要展现动画
- (void)setOn:(BOOL)on animated:(BOOL)animated; // does not send action  不会发送操作(只是根据参数判断在开关在on/off状态下是否执行某个动画)

@end

NS_ASSUME_NONNULL_END
