//
//  UILabel.h
//  UIKit
//
//  Copyright (c) 2006-2015 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIView.h>
#import <UIKit/UIStringDrawing.h>
#import <UIKit/UIKitDefines.h>

NS_ASSUME_NONNULL_BEGIN

@class UIColor, UIFont;

NS_CLASS_AVAILABLE_IOS(2_0) @interface UILabel : UIView <NSCoding>

@property(nullable, nonatomic,copy)   NSString           *text;     // default is nil设置文字
@property(null_resettable, nonatomic,strong) UIFont      *font;   // default is nil (system font 17 plain)设置字体（系统字体17号普通字体）
@property(null_resettable, nonatomic,strong) UIColor     *textColor;       // default is nil (text draws black)设置文字颜色（默认文字绘制黑色）
@property(nullable, nonatomic,strong) UIColor            *shadowColor;     // default is nil (no shadow)设置阴影颜色（默认没有阴影）
   //使用方法：[label setShadowColor:[UIColor blackColor]];
@property(nonatomic)        CGSize             shadowOffset;    // default is CGSizeMake(0, -1) -- a top shadow设置阴影偏移（默认偏移量(0, -1)－－顶部阴影）
   //使用方法[label setShadowOffset:CGSizeMake(-1, -1)];
@property(nonatomic)        NSTextAlignment    textAlignment;   // default is NSTextAlignmentLeft设置标签文本对齐方式（默认左对齐）
//abel.textAlignment = NSTextAlignmentCenter（居中对齐）NSTextAlignmentLeft（左对齐）、 NSTextAlignmentRight（右对齐）
@property(nonatomic)        NSLineBreakMode    lineBreakMode;   // default is NSLineBreakByTruncatingTail. used for single and multiple lines of text设置标签最多显示行数,如果为0则表示多行(默认是NSLineBreakByTruncatingTail。用于单和多行文本)
//使用方法：//设置文字过长时的显示格式label.lineBreakMode = NSLineBreakByCharWrapping;以字符为显示单位显示，后面部分省略不显示。label.lineBreakMode = NSLineBreakByClipping;剪切与文本宽度相同的内容长度，后半部分被删除。label.lineBreakMode = NSLineBreakByTruncatingHead;前面部分文字以……方式省略，显示尾部文字内容。label.lineBreakMode = NSLineBreakByTruncatingMiddle;中间的内容以……方式省略，显示头尾的文字内容。label.lineBreakMode = NSLineBreakByTruncatingTail;结尾部分的内容以……方式省略，显示头的文字内容。label.lineBreakMode = NSLineBreakByWordWrapping;以单词为显示单位显示，后面部分省略不显示。


// the underlying attributed string drawn by the label, if set, the label ignores the properties above.(底层带属性字符串的标签,如果设置,上面的标签忽略了属性。)
@property(nullable, nonatomic,copy)   NSAttributedString *attributedText NS_AVAILABLE_IOS(6_0);  // default is nil设置标签属性文本
//使用方法：
//1.	使用这个类，必须先导入CoreText框架。
//2.	给UILabel设置attributedText了会导致给UILabel中text，font，textColor，shadowColor，shadowOffset，textAlignment，lineBreakMode这7个属性设置值时无效果。
//3.这个框架的应用场景一般在图文混排和搜索功能中应用比较多。
//NSString *text = @"first";
//NSMutableAttributedString *textLabelStr = [[NSMutableAttributedString alloc] initWithString:text];
//[textLabelStr setAttributes:@{NSForegroundColorAttributeName : [UIColor lightGrayColor],NSFontAttributeName : [UIFont systemFontOfSize:17]} range:NSMakeRange(11, 10)];
//label.attributedText = textLabelStr;



// the 'highlight' property is used by subclasses for such things as pressed states. it's useful to make it part of the base class as a user property(在“highlight”属性是由子类诸如按下状态使用。它是有用的，使之基类的一部分作为用户属性)
@property(nullable, nonatomic,strong)   UIColor *highlightedTextColor; // default is nil设置高亮显示时的文本颜色
@property(nonatomic,getter=isHighlighted) BOOL     highlighted;          // default is NO 设置是否高亮显示

@property(nonatomic,getter=isUserInteractionEnabled) BOOL userInteractionEnabled;  // default is NO 该属性决定UIView是否接受并响应用户的交互  介绍：http://my.oschina.net/hmj/blog/108002
@property(nonatomic,getter=isEnabled)                BOOL enabled;                 // default is YES. changes how the label is drawn只是决定了Label的绘制方式，将它设置为NO将会使文本变暗，表示它没有激活，这时向它设置颜色值是无效的。

// this determines the number of lines to draw and what to do when sizeToFit is called. default value is 1 (single line). A value of 0 means no limit（当调用sizetofit时，决定了要有多少行去实现。默认值是1（单线）。值为0表示没有限制）
// if the height of the text reaches the # of lines or the height of the view is less than the # of lines allowed, the text will be
// truncated using the line break mode.（如果文本的高度达到#线或视图的高度小于允许的行号,使用换行符的文本将被截断模式）

@property(nonatomic) NSInteger numberOfLines;//设置标签最多显示行数,如果为0则表示多行

// these next 3 property allow the label to be autosized to fit a certain width by scaling the font size(s) by a scaling factor >= the minimum scaling factor
// and to specify how the text baseline moves when it needs to shrink the font.（这些下面3属性允许在标签被自动调整大小由一个缩放因子缩放的字体大小（S）> =最小比例因子，以适应一定的宽度，并指定当它需要如何文本基线移动到收缩的字体。）

@property(nonatomic) BOOL adjustsFontSizeToFitWidth;         // default is NO 设置当这个属性是YES，标签可能改变标签文本的字母间距，以使该文本更适合标签的边界内。此属性的字符串，而不管当前行的行的裁剪模式。该属性的默认值是NO。
@property(nonatomic) UIBaselineAdjustment baselineAdjustment; // default is UIBaselineAdjustmentAlignBaselines
//使用方法：//有三种方式
//typedef enum {
//    UIBaselineAdjustmentAlignBaselines = 0, 默认值文本最上端于label中线对齐
//    UIBaselineAdjustmentAlignCenters,//文本中线于label中线对齐
//    UIBaselineAdjustmentNone,//文本最低端与label中线对齐
//} UIBaselineAdjustment;
@property(nonatomic) CGFloat minimumScaleFactor NS_AVAILABLE_IOS(6_0); // default is 0.0设置最小字体大小，当字体小于这个最小值时无效，显示此属性值


// Tightens inter-character spacing in attempt to fit lines wider than the available space if the line break mode is one of the truncation modes before starting to truncate.（收紧字符间间距在试图以适合线比可用空间更宽如果线断模式是开始截断之前截断模式之一。）
// The maximum amount of tightening performed is determined by the system based on contexts such as font, line width, etc.（紧缩执行的最大数量由基于上下文，如字体，线宽等的系统来确定）
@property(nonatomic) BOOL allowsDefaultTighteningForTruncation NS_AVAILABLE_IOS(9_0); // default is NO允许默认收紧截断

// override points. can adjust rect before calling super.（覆盖点。可以在调用超之前先调整正确。）
// label has default content mode of UIViewContentModeRedraw（标签有UIViewContentModeRedraw的默认内容模式）

- (CGRect)textRectForBounds:(CGRect)bounds limitedToNumberOfLines:(NSInteger)numberOfLines;//计算UIlabel 随字体多行后的高度
- (void)drawTextInRect:(CGRect)rect;//绘制text到指定区域
//使用方法:
//CGRect result,bounds;
//bounds = CGRectMake(0, 0,200, 300);
//heightLabel = [myLabel textRectForBounds:bounds limitedToNumberOfLines:20];//计算20行后的Label的Frame
//NSLog(@"%f",heightLabel.size.height);
//- (void)drawTextInRect:(CGRect)rect
//需要重载此方法，然后由子类调用，重写时调用super可以按默认图形属性绘制,若自己完全重写绘制函数,就不用调用super了

// Support for constraint-based layout (auto layout)(支持基于布局(自动布局))
// If nonzero, this is used when determining -intrinsicContentSize for multiline labels(如果非零,这是在确定-intrinsicContentSize用于多行标签)
@property(nonatomic) CGFloat preferredMaxLayoutWidth NS_AVAILABLE_IOS(6_0);//设置preferredMaxLayoutWidth,autolayout才会判断到折行的位置，才能正确的显示多行的UILabel;
////但是 preferredMaxLayoutWidth设置为多少才是正确的呢？如果你知道一个确切的width当然是最好的，那么直接设置即可，但是如果UILabel的宽度是自适应的，不确定，那么可以使用如下的代码设置
//- (void)layoutSubViews
//{
//    [super layoutSubViews];
//    self.label.preferredMaxLayoutWidth = self.label.bounds.size.width;
//}
//当label已经显示到界面上的时候，那么宽度就已经确定了，可以直接用此宽度作为最大autolayout宽度设置。这样就正常了
//


// deprecated:弃用

@property(nonatomic) CGFloat minimumFontSize NS_DEPRECATED_IOS(2_0, 6_0) __TVOS_PROHIBITED; // deprecated - use minimumScaleFactor. default is 0.0 设置最小字体大小，当字体小于这个最小值时无效，显示此属性值，iOS6.0之后：minimumScaleFactor（弃用,使用minimumScaleFactor。默认是0.0）

// Non-functional.  Hand tune by using NSKernAttributeName to affect tracking, or consider using the allowsDefaultTighteningForTruncation property.（非功能性。手调整利用NSKernAttributeName影响跟踪,或考虑使用allowsDefaultTighteningForTruncation属性。）
@property(nonatomic) BOOL adjustsLetterSpacingToFitWidth NS_DEPRECATED_IOS(6_0,7_0) __TVOS_PROHIBITED;//改变字母之间的间距来适应Label大小(ios 7.0 放弃)

@end

NS_ASSUME_NONNULL_END
