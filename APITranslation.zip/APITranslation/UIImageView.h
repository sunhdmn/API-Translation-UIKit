//
//  UIImageView.h
//  UIKit
//UIImageView代表一个图片显示控件，它直接继承了UIView基类，没有继承UIControl，因此，UIImage只能作为图片的显示控件，不能接受用户输入，也不能与用户交互(添加手势即可与用户交互)，它只是一个静态控件。
//  Copyright (c) 2006-2015 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIView.h>
#import <UIKit/UIKitDefines.h>

NS_ASSUME_NONNULL_BEGIN

@class UIImage;

NS_CLASS_AVAILABLE_IOS(2_0) @interface UIImageView : UIView 

- (instancetype)initWithImage:(nullable UIImage *)image; //初始化时设置一张图片 (默认是defaut状态)
- (instancetype)initWithImage:(nullable UIImage *)image highlightedImage:(nullable UIImage *)highlightedImage NS_AVAILABLE_IOS(3_0);    //初始化时设置默认图片和其高亮图片 (可以设置default状态和高亮highlighted状态)

@property (nullable, nonatomic, strong) UIImage *image; // default is nil 默认图片
@property (nullable, nonatomic, strong) UIImage *highlightedImage NS_AVAILABLE_IOS(3_0); // default is nil 设置高亮图片
@property (nonatomic, getter=isUserInteractionEnabled) BOOL userInteractionEnabled; // default is NO 是否为UIImageView添加点击事件(用户交互)(默认情况下是NO----不能产生点击事件)

@property (nonatomic, getter=isHighlighted) BOOL highlighted NS_AVAILABLE_IOS(3_0); // default is NO //是否设置高亮状态(默认NO----不设置高亮状态)

// these allow a set of images to be animated. the array may contain multiple copies of the same  这些允许一组图像动画。该数组可能包含相同的多个副本

@property (nullable, nonatomic, copy) NSArray<UIImage *> *animationImages; // The array must contain UIImages. Setting hides the single image. default is nil 访问或者设置该UIImageView需要动画显示的多张图片。该属性的值是一个NSArray对象。  ( 数组必须包含UIImages。设置过程隐藏了单个的图片(默认状态下的帧动画))。

//因为UIImageView的animation不会边用边释放,解决方法：原理就是用NSTimer去实现apple的UIImageView animation的效果：用NSTimer每隔一个时间戳去设置一次
//imageSTimer *myAnimatedTimer = [NSTimer scheduledTimerWithTimeInterval:0.04 target:self selector:@selector(setNextImage)userInfo:nil repeats:YES];
//-（void)setNextImage
//{
//    
//    myAnimatedView.image = [UIImage imageNamed：[NSStringstringWithFormat:@"image%i.png",nextImage]];
//}


@property (nullable, nonatomic, copy) NSArray<UIImage *> *highlightedAnimationImages NS_AVAILABLE_IOS(3_0); // The array must contain UIImages. Setting hides the single image. default is nil  访问或者设置该UIImageView高亮状态下需要动画显示的多张图片。该属性的值是一个NSArray对象。(数组必须包含UIImages。设置过程隐藏了单个的图片(高亮状态下的帧动画))。

@property (nonatomic) NSTimeInterval animationDuration;         // for one cycle of images. default is number of images * 1/30th of a second (i.e. 30 fps)
//访问或设置该UIImageView的动画持续时间。(动画播放时间，对于一个周期的图像，默认的是图像是一秒30帧。)
@property (nonatomic) NSInteger      animationRepeatCount;      // 0 means infinite (default is 0) 访问或设置该UIImageView的动画重复次数。 (动画重复次数(默认是0 --- 无限次))

// When tintColor is non-nil, any template images set on the image view will be colorized with that color.  当渲染色(tintColor)的值非空(不为0)时,任何模板的图片设置图片视图的时候,将会被附上那个tintColor
// The tintColor is inherited through the superview hierarchy. See UIView for more information.  给控件内子视图设置颜色。详细信息请见 UIImage类属性。
@property (null_resettable, nonatomic, strong) UIColor *tintColor //渲染色NS_AVAILABLE_IOS(7_0);

- (void)startAnimating; //开始播放动画
- (void)stopAnimating;  //停止播放动画
- (BOOL)isAnimating;    //是否在动画中

// if YES, the UIImageView will display a focused appearance when any of its immediate or distant superviews become focused
//
@property (nonatomic) BOOL adjustsImageWhenAncestorFocused UIKIT_AVAILABLE_TVOS_ONLY(9_0); //是否是另一个视图的一部分

// if adjustsImageWhenAncestorFocused is set, the image view may display its image in a larger frame when focused.
// this layout guide can be used to align other elements with the image view's focused frame.
//如果设置了adjustsImageWhenAncestorFocused，图像视图可以在一个更大的 frame 中显示其图片的焦点。这个布局指南，可用于将其他元素与图像视图的聚焦帧对齐。
@property(readonly,strong) UILayoutGuide *focusedFrameGuide UIKIT_AVAILABLE_TVOS_ONLY(9_0);

@end

NS_ASSUME_NONNULL_END
